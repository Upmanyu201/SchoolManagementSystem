# Testing Rules for Enterprise Applications

## Core Testing Principles

### 1. Test Pyramid Strategy
- **Unit Tests (70%)**: Test individual functions and methods
- **Integration Tests (20%)**: Test component interactions
- **End-to-End Tests (10%)**: Test complete user workflows

### 2. Test-Driven Development (TDD)
- Write tests before implementation
- Red-Green-Refactor cycle
- Tests as living documentation
- Continuous feedback loop

### 3. Testing Standards
- Tests should be fast, reliable, and independent
- Each test should have a single responsibility
- Tests should be readable and maintainable
- Mock external dependencies

## Unit Testing

### Model Testing
```python
# tests/test_models.py
from django.test import TestCase
from django.core.exceptions import ValidationError
from decimal import Decimal
from students.models import Student
from fees.models import FeeDeposit

class StudentModelTest(TestCase):
    """Test cases for Student model."""
    
    def setUp(self):
        """Set up test data."""
        self.student_data = {
            'first_name': 'John',
            'last_name': 'Doe',
            'admission_number': 'STU001',
            'email': 'john.doe@example.com',
            'mobile_number': '1234567890'
        }
    
    def test_student_creation_success(self):
        """Test successful student creation."""
        student = Student.objects.create(**self.student_data)
        
        self.assertEqual(student.first_name, 'John')
        self.assertEqual(student.last_name, 'Doe')
        self.assertEqual(student.full_name, 'John Doe')
        self.assertEqual(str(student), 'John Doe (STU001)')
    
    def test_student_validation_rules(self):
        """Test student validation constraints."""
        # Test unique admission number
        Student.objects.create(**self.student_data)
        
        with self.assertRaises(ValidationError):
            duplicate_student = Student(**self.student_data)
            duplicate_student.full_clean()
    
    def test_due_amount_calculation(self):
        """Test due amount calculation logic."""
        student = Student.objects.create(**self.student_data)
        
        # Create fee deposit
        FeeDeposit.objects.create(
            student=student,
            amount=Decimal('1000.00'),
            payment_date='2024-01-15'
        )
        
        # Test calculation
        student.update_due_amount()
        self.assertIsInstance(student.due_amount, Decimal)
        self.assertGreaterEqual(student.due_amount, Decimal('0'))
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions."""
        # Test with minimum required fields
        minimal_data = {
            'first_name': 'A',
            'last_name': 'B',
            'admission_number': '1',
            'email': 'a@b.co',
            'mobile_number': '1000000000'
        }
        student = Student.objects.create(**minimal_data)
        self.assertEqual(student.full_name, 'A B')
        
        # Test with maximum field lengths
        long_name_data = self.student_data.copy()
        long_name_data['first_name'] = 'A' * 50  # Max length
        student = Student.objects.create(**long_name_data)
        self.assertEqual(len(student.first_name), 50)
```

### View Testing
```python
# tests/test_views.py
from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth import get_user_model
from students.models import Student

User = get_user_model()

class StudentViewTest(TestCase):
    """Test cases for student views."""
    
    def setUp(self):
        """Set up test data."""
        self.client = Client()
        self.user = User.objects.create_user(
            username='testuser',
            email='test@example.com',
            password='testpass123'
        )
        self.student = Student.objects.create(
            first_name='John',
            last_name='Doe',
            admission_number='STU001',
            email='john@example.com',
            mobile_number='1234567890'
        )
    
    def test_student_list_view_authenticated(self):
        """Test student list view for authenticated users."""
        self.client.login(username='testuser', password='testpass123')
        
        response = self.client.get(reverse('students:student_list'))
        
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'John Doe')
        self.assertContains(response, 'STU001')
    
    def test_student_list_view_unauthenticated(self):
        """Test student list view redirects unauthenticated users."""
        response = self.client.get(reverse('students:student_list'))
        
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, '/login/?next=/students/')
    
    def test_add_student_post_valid_data(self):
        """Test adding student with valid data."""
        self.client.login(username='testuser', password='testpass123')
        
        student_data = {
            'first_name': 'Jane',
            'last_name': 'Smith',
            'admission_number': 'STU002',
            'email': 'jane@example.com',
            'mobile_number': '9876543210'
        }
        
        response = self.client.post(reverse('students:add_student'), student_data)
        
        self.assertEqual(response.status_code, 302)  # Redirect after success
        self.assertTrue(Student.objects.filter(admission_number='STU002').exists())
    
    def test_add_student_post_invalid_data(self):
        """Test adding student with invalid data."""
        self.client.login(username='testuser', password='testpass123')
        
        invalid_data = {
            'first_name': '',  # Required field missing
            'last_name': 'Smith',
            'admission_number': 'STU001',  # Duplicate
            'email': 'invalid-email',  # Invalid format
            'mobile_number': '123'  # Too short
        }
        
        response = self.client.post(reverse('students:add_student'), invalid_data)
        
        self.assertEqual(response.status_code, 200)  # Form redisplayed with errors
        self.assertFormError(response, 'form', 'first_name', 'This field is required.')
        self.assertFormError(response, 'form', 'email', 'Enter a valid email address.')
```

### Service Testing
```python
# tests/test_services.py
from django.test import TestCase
from unittest.mock import patch, Mock
from students.services import StudentService, NotificationService
from students.models import Student

class StudentServiceTest(TestCase):
    """Test cases for StudentService."""
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='admin',
            email='admin@example.com',
            password='adminpass'
        )
        self.student_data = {
            'first_name': 'John',
            'last_name': 'Doe',
            'admission_number': 'STU001',
            'email': 'john@example.com',
            'mobile_number': '1234567890'
        }
    
    def test_enroll_student_success(self):
        """Test successful student enrollment."""
        student = StudentService.enroll_student(self.student_data, self.user)
        
        self.assertIsInstance(student, Student)
        self.assertEqual(student.first_name, 'John')
        self.assertEqual(student.admission_number, 'STU001')
    
    def test_enroll_student_duplicate_admission_number(self):
        """Test enrollment with duplicate admission number."""
        # Create existing student
        Student.objects.create(**self.student_data)
        
        with self.assertRaises(ValidationError):
            StudentService.enroll_student(self.student_data, self.user)
    
    @patch('students.services.NotificationService.send_welcome_message')
    def test_enroll_student_notification_sent(self, mock_notification):
        """Test that welcome notification is sent on enrollment."""
        student = StudentService.enroll_student(self.student_data, self.user)
        
        mock_notification.assert_called_once_with(student)
    
    def test_enroll_student_insufficient_permissions(self):
        """Test enrollment with insufficient permissions."""
        user_without_permission = User.objects.create_user(
            username='limited',
            email='limited@example.com',
            password='limitedpass'
        )
        
        with self.assertRaises(PermissionError):
            StudentService.enroll_student(self.student_data, user_without_permission)
```

## Integration Testing

### API Testing
```python
# tests/test_api.py
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth import get_user_model
from students.models import Student

User = get_user_model()

class StudentAPITest(APITestCase):
    """Test cases for Student API endpoints."""
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='apiuser',
            email='api@example.com',
            password='apipass123'
        )
        self.student = Student.objects.create(
            first_name='John',
            last_name='Doe',
            admission_number='STU001',
            email='john@example.com',
            mobile_number='1234567890'
        )
    
    def test_get_student_list_authenticated(self):
        """Test GET /api/students/ with authentication."""
        self.client.force_authenticate(user=self.user)
        
        response = self.client.get('/api/students/')
        
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['results']), 1)
        self.assertEqual(response.data['results'][0]['admission_number'], 'STU001')
    
    def test_get_student_list_unauthenticated(self):
        """Test GET /api/students/ without authentication."""
        response = self.client.get('/api/students/')
        
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)
    
    def test_create_student_valid_data(self):
        """Test POST /api/students/ with valid data."""
        self.client.force_authenticate(user=self.user)
        
        student_data = {
            'first_name': 'Jane',
            'last_name': 'Smith',
            'admission_number': 'STU002',
            'email': 'jane@example.com',
            'mobile_number': '9876543210'
        }
        
        response = self.client.post('/api/students/', student_data)
        
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['admission_number'], 'STU002')
        self.assertTrue(Student.objects.filter(admission_number='STU002').exists())
    
    def test_create_student_invalid_data(self):
        """Test POST /api/students/ with invalid data."""
        self.client.force_authenticate(user=self.user)
        
        invalid_data = {
            'first_name': '',
            'last_name': 'Smith',
            'admission_number': 'STU001',  # Duplicate
            'email': 'invalid-email',
            'mobile_number': '123'
        }
        
        response = self.client.post('/api/students/', invalid_data)
        
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('first_name', response.data)
        self.assertIn('email', response.data)
```

### Database Integration Testing
```python
# tests/test_database_integration.py
from django.test import TransactionTestCase
from django.db import transaction
from students.models import Student
from fees.models import FeeDeposit

class DatabaseIntegrationTest(TransactionTestCase):
    """Test database transactions and constraints."""
    
    def test_atomic_transaction_rollback(self):
        """Test that failed transactions are rolled back properly."""
        initial_count = Student.objects.count()
        
        try:
            with transaction.atomic():
                # Create valid student
                student = Student.objects.create(
                    first_name='John',
                    last_name='Doe',
                    admission_number='STU001',
                    email='john@example.com',
                    mobile_number='1234567890'
                )
                
                # Create duplicate (should fail)
                Student.objects.create(
                    first_name='Jane',
                    last_name='Smith',
                    admission_number='STU001',  # Duplicate admission number
                    email='jane@example.com',
                    mobile_number='9876543210'
                )
        except Exception:
            pass  # Expected to fail
        
        # Verify rollback - no students should be created
        self.assertEqual(Student.objects.count(), initial_count)
    
    def test_foreign_key_constraints(self):
        """Test foreign key constraint enforcement."""
        student = Student.objects.create(
            first_name='John',
            last_name='Doe',
            admission_number='STU001',
            email='john@example.com',
            mobile_number='1234567890'
        )
        
        # Create fee deposit
        deposit = FeeDeposit.objects.create(
            student=student,
            amount=1000,
            payment_date='2024-01-15'
        )
        
        # Verify relationship
        self.assertEqual(deposit.student, student)
        self.assertIn(deposit, student.fee_deposits.all())
        
        # Test cascade delete
        student_id = student.id
        student.delete()
        
        # Verify deposit is also deleted (cascade)
        self.assertFalse(FeeDeposit.objects.filter(student_id=student_id).exists())
```

## End-to-End Testing

### Selenium Testing
```python
# tests/test_e2e.py
from django.contrib.staticfiles.testing import StaticLiveServerTestCase
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from django.contrib.auth import get_user_model

User = get_user_model()

class StudentManagementE2ETest(StaticLiveServerTestCase):
    """End-to-end tests for student management workflow."""
    
    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.selenium = webdriver.Chrome()  # Requires ChromeDriver
        cls.selenium.implicitly_wait(10)
    
    @classmethod
    def tearDownClass(cls):
        cls.selenium.quit()
        super().tearDownClass()
    
    def setUp(self):
        """Set up test data."""
        self.user = User.objects.create_user(
            username='e2euser',
            email='e2e@example.com',
            password='e2epass123'
        )
    
    def test_complete_student_enrollment_workflow(self):
        """Test complete student enrollment workflow."""
        # Login
        self.selenium.get(f'{self.live_server_url}/login/')
        
        username_input = self.selenium.find_element(By.NAME, 'username')
        password_input = self.selenium.find_element(By.NAME, 'password')
        
        username_input.send_keys('e2euser')
        password_input.send_keys('e2epass123')
        
        self.selenium.find_element(By.XPATH, '//button[@type="submit"]').click()
        
        # Navigate to add student page
        self.selenium.get(f'{self.live_server_url}/students/add/')
        
        # Fill student form
        self.selenium.find_element(By.NAME, 'first_name').send_keys('John')
        self.selenium.find_element(By.NAME, 'last_name').send_keys('Doe')
        self.selenium.find_element(By.NAME, 'admission_number').send_keys('E2E001')
        self.selenium.find_element(By.NAME, 'email').send_keys('john.e2e@example.com')
        self.selenium.find_element(By.NAME, 'mobile_number').send_keys('1234567890')
        
        # Submit form
        self.selenium.find_element(By.XPATH, '//button[@type="submit"]').click()
        
        # Wait for success message
        WebDriverWait(self.selenium, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'alert-success'))
        )
        
        # Verify student appears in list
        self.selenium.get(f'{self.live_server_url}/students/')
        
        self.assertIn('John Doe', self.selenium.page_source)
        self.assertIn('E2E001', self.selenium.page_source)
    
    def test_form_validation_errors(self):
        """Test form validation error display."""
        # Login and navigate to add student
        self.selenium.get(f'{self.live_server_url}/login/')
        # ... login code ...
        
        self.selenium.get(f'{self.live_server_url}/students/add/')
        
        # Submit empty form
        self.selenium.find_element(By.XPATH, '//button[@type="submit"]').click()
        
        # Wait for error messages
        WebDriverWait(self.selenium, 10).until(
            EC.presence_of_element_located((By.CLASS_NAME, 'error'))
        )
        
        # Verify error messages are displayed
        errors = self.selenium.find_elements(By.CLASS_NAME, 'error')
        self.assertGreater(len(errors), 0)
```

## Performance Testing

### Load Testing
```python
# tests/test_performance.py
from django.test import TestCase
from django.test.utils import override_settings
from django.db import connection
from django.test.client import Client
import time

class PerformanceTest(TestCase):
    """Performance tests for critical operations."""
    
    def setUp(self):
        """Set up test data."""
        # Create test students
        students = []
        for i in range(100):
            students.append(Student(
                first_name=f'Student{i}',
                last_name='Test',
                admission_number=f'PERF{i:03d}',
                email=f'student{i}@test.com',
                mobile_number=f'123456{i:04d}'
            ))
        Student.objects.bulk_create(students)
    
    def test_student_list_query_performance(self):
        """Test student list query performance."""
        start_time = time.time()
        initial_queries = len(connection.queries)
        
        # Execute the query
        students = list(Student.objects.select_related('student_class').all())
        
        end_time = time.time()
        final_queries = len(connection.queries)
        
        # Performance assertions
        self.assertLess(end_time - start_time, 1.0)  # Should complete in <1 second
        self.assertLess(final_queries - initial_queries, 5)  # Should use <5 queries
        self.assertEqual(len(students), 100)
    
    def test_bulk_operations_performance(self):
        """Test bulk operations performance."""
        # Test bulk update
        start_time = time.time()
        
        students = Student.objects.all()
        for student in students:
            student.due_amount = 1000
        
        Student.objects.bulk_update(students, ['due_amount'], batch_size=50)
        
        end_time = time.time()
        
        # Should complete bulk update quickly
        self.assertLess(end_time - start_time, 2.0)
        
        # Verify all students updated
        updated_count = Student.objects.filter(due_amount=1000).count()
        self.assertEqual(updated_count, 100)
```

## Test Data Management

### Fixtures and Factories
```python
# tests/factories.py
import factory
from django.contrib.auth import get_user_model
from students.models import Student
from fees.models import FeeDeposit

User = get_user_model()

class UserFactory(factory.django.DjangoModelFactory):
    """Factory for creating test users."""
    
    class Meta:
        model = User
    
    username = factory.Sequence(lambda n: f'user{n}')
    email = factory.LazyAttribute(lambda obj: f'{obj.username}@example.com')
    first_name = factory.Faker('first_name')
    last_name = factory.Faker('last_name')

class StudentFactory(factory.django.DjangoModelFactory):
    """Factory for creating test students."""
    
    class Meta:
        model = Student
    
    first_name = factory.Faker('first_name')
    last_name = factory.Faker('last_name')
    admission_number = factory.Sequence(lambda n: f'STU{n:04d}')
    email = factory.LazyAttribute(lambda obj: f'{obj.first_name.lower()}.{obj.last_name.lower()}@example.com')
    mobile_number = factory.Faker('numerify', text='##########')

class FeeDepositFactory(factory.django.DjangoModelFactory):
    """Factory for creating test fee deposits."""
    
    class Meta:
        model = FeeDeposit
    
    student = factory.SubFactory(StudentFactory)
    amount = factory.Faker('pydecimal', left_digits=4, right_digits=2, positive=True)
    payment_date = factory.Faker('date_this_year')

# Usage in tests
class StudentTestWithFactory(TestCase):
    def test_student_creation_with_factory(self):
        """Test student creation using factory."""
        student = StudentFactory()
        
        self.assertIsInstance(student, Student)
        self.assertTrue(student.admission_number.startswith('STU'))
        self.assertIn('@example.com', student.email)
    
    def test_multiple_students_with_deposits(self):
        """Test creating multiple students with deposits."""
        students = StudentFactory.create_batch(5)
        
        for student in students:
            FeeDepositFactory.create_batch(3, student=student)
        
        self.assertEqual(Student.objects.count(), 5)
        self.assertEqual(FeeDeposit.objects.count(), 15)
```

## Test Configuration

### Test Settings
```python
# settings/test.py
from .base import *

# Test database
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': ':memory:',
    }
}

# Disable migrations for faster tests
class DisableMigrations:
    def __contains__(self, item):
        return True
    
    def __getitem__(self, item):
        return None

MIGRATION_MODULES = DisableMigrations()

# Test-specific settings
PASSWORD_HASHERS = [
    'django.contrib.auth.hashers.MD5PasswordHasher',  # Faster for tests
]

EMAIL_BACKEND = 'django.core.mail.backends.locmem.EmailBackend'

# Disable logging during tests
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'null': {
            'class': 'logging.NullHandler',
        },
    },
    'root': {
        'handlers': ['null'],
    },
}

# Test coverage settings
COVERAGE_REPORT_HTML_OUTPUT_DIR = 'htmlcov'
COVERAGE_MODULE_EXCLUDES = [
    'tests$', 'settings$', 'urls$', 'locale$',
    'migrations', 'fixtures', 'venv'
]
```

## Continuous Integration

### Test Automation
```yaml
# .github/workflows/tests.yml
name: Tests

on: [push, pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    
    services:
      postgres:
        image: postgres:13
        env:
          POSTGRES_PASSWORD: postgres
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    
    steps:
    - uses: actions/checkout@v2
    
    - name: Set up Python
      uses: actions/setup-python@v2
      with:
        python-version: 3.9
    
    - name: Install dependencies
      run: |
        pip install -r requirements-test.txt
    
    - name: Run tests
      run: |
        python manage.py test --settings=settings.test
    
    - name: Generate coverage report
      run: |
        coverage run --source='.' manage.py test --settings=settings.test
        coverage xml
    
    - name: Upload coverage to Codecov
      uses: codecov/codecov-action@v1
```

## Testing Checklist

### Pre-Commit Testing
- [ ] All unit tests pass
- [ ] Integration tests pass
- [ ] Code coverage meets minimum threshold (80%+)
- [ ] No linting errors
- [ ] Performance tests within acceptable limits

### Release Testing
- [ ] Full test suite passes
- [ ] End-to-end tests complete successfully
- [ ] Load testing completed
- [ ] Security tests pass
- [ ] Browser compatibility verified
- [ ] Mobile responsiveness tested

### Test Maintenance
- [ ] Remove obsolete tests
- [ ] Update tests for changed functionality
- [ ] Add tests for new features
- [ ] Review and improve test coverage
- [ ] Update test documentation

Remember: Comprehensive testing is essential for maintaining code quality, preventing regressions, and ensuring reliable enterprise applications. Invest time in writing good tests—they pay dividends in reduced bugs and easier maintenance.