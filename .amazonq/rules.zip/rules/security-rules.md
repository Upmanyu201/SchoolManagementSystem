# Enterprise Security Rules

## Core Security Principles

### 1. Defense in Depth
- Multiple layers of security
- Never rely on single security measure
- Assume every layer can be compromised
- Validate at every boundary

### 2. Principle of Least Privilege
- Grant minimum necessary permissions
- Regular permission audits
- Role-based access control
- Time-limited access tokens

### 3. Fail Securely
- Default to deny access
- Secure error handling
- No sensitive data in error messages
- Graceful degradation

## Authentication & Authorization

### Strong Authentication
```python
# Good - Strong password requirements
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator', 'OPTIONS': {'min_length': 12}},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Implement MFA
class CustomUser(AbstractUser):
    is_mfa_enabled = models.BooleanField(default=False)
    mfa_secret = models.CharField(max_length=32, blank=True)
```

### Session Security
```python
# Secure session configuration
SESSION_COOKIE_SECURE = True           # HTTPS only
SESSION_COOKIE_HTTPONLY = True         # No JavaScript access
SESSION_COOKIE_SAMESITE = 'Strict'     # CSRF protection
SESSION_COOKIE_AGE = 3600              # 1 hour timeout
SESSION_EXPIRE_AT_BROWSER_CLOSE = True
```

### Permission-Based Access
```python
# Good - Granular permissions
class StudentViewSet(viewsets.ModelViewSet):
    permission_classes = [IsAuthenticated, HasStudentPermission]
    
    def get_queryset(self):
        user = self.request.user
        if user.is_teacher:
            return Student.objects.filter(class_teacher=user)
        elif user.is_admin:
            return Student.objects.all()
        else:
            return Student.objects.none()
```

## Input Validation & Sanitization

### Always Validate Input
```python
# Good - Comprehensive validation
class StudentForm(forms.ModelForm):
    def clean_mobile_number(self):
        mobile = self.cleaned_data['mobile_number']
        if not re.match(r'^\+?1?\d{9,15}$', mobile):
            raise ValidationError("Invalid mobile number format")
        return mobile
    
    def clean_email(self):
        email = self.cleaned_data['email']
        if User.objects.filter(email=email).exists():
            raise ValidationError("Email already exists")
        return email

# Custom validators
def validate_file_extension(value):
    allowed_extensions = ['.pdf', '.jpg', '.png', '.docx']
    ext = os.path.splitext(value.name)[1].lower()
    if ext not in allowed_extensions:
        raise ValidationError(f'File type {ext} not allowed')

def validate_file_size(value):
    limit = 5 * 1024 * 1024  # 5MB
    if value.size > limit:
        raise ValidationError('File too large. Size should not exceed 5MB')
```

### SQL Injection Prevention
```python
# Good - Use ORM
students = Student.objects.filter(name__icontains=search_term)

# Good - Parameterized queries when raw SQL needed
cursor.execute("SELECT * FROM students WHERE name = %s", [name])

# Never - String concatenation
cursor.execute(f"SELECT * FROM students WHERE name = '{name}'")  # DANGEROUS
```

### XSS Prevention
```python
# Good - Auto-escape in templates
{{ user_input|escape }}

# Good - Mark safe only when necessary
from django.utils.safestring import mark_safe
safe_html = mark_safe(sanitized_content)

# Use bleach for HTML sanitization
import bleach
clean_html = bleach.clean(user_html, tags=['p', 'br'], strip=True)
```

## Data Protection

### Encryption at Rest
```python
# Encrypt sensitive fields
from django_cryptography.fields import encrypt

class Student(models.Model):
    name = models.CharField(max_length=100)
    ssn = encrypt(models.CharField(max_length=11))  # Encrypted field
    
# Environment-based encryption keys
FIELD_ENCRYPTION_KEY = os.environ.get('FIELD_ENCRYPTION_KEY')
```

### Encryption in Transit
```python
# Force HTTPS in production
SECURE_SSL_REDIRECT = True
SECURE_HSTS_SECONDS = 31536000
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
```

### Sensitive Data Handling
```python
# Good - Hash passwords
from django.contrib.auth.hashers import make_password
password = make_password(raw_password)

# Good - Secure random generation
import secrets
token = secrets.token_urlsafe(32)

# Never store sensitive data in logs
logger.info(f"User {user.id} logged in")  # Good
logger.info(f"User {user.password} logged in")  # DANGEROUS
```

## File Upload Security

### Secure File Handling
```python
def secure_file_upload(request):
    if request.method == 'POST':
        uploaded_file = request.FILES['file']
        
        # Validate file type
        allowed_types = ['image/jpeg', 'image/png', 'application/pdf']
        if uploaded_file.content_type not in allowed_types:
            return JsonResponse({'error': 'File type not allowed'})
        
        # Validate file size
        if uploaded_file.size > 5 * 1024 * 1024:  # 5MB
            return JsonResponse({'error': 'File too large'})
        
        # Scan for malware (if available)
        if not scan_file_for_malware(uploaded_file):
            return JsonResponse({'error': 'File failed security scan'})
        
        # Generate secure filename
        filename = f"{uuid.uuid4()}{os.path.splitext(uploaded_file.name)[1]}"
        
        # Store in secure location
        file_path = os.path.join(settings.MEDIA_ROOT, 'secure', filename)
        with open(file_path, 'wb+') as destination:
            for chunk in uploaded_file.chunks():
                destination.write(chunk)
```

## API Security

### Rate Limiting
```python
from django_ratelimit.decorators import ratelimit

@ratelimit(key='ip', rate='100/h', method='POST')
def api_endpoint(request):
    # API logic here
    pass

# Global rate limiting
RATELIMIT_ENABLE = True
RATELIMIT_USE_CACHE = 'default'
```

### API Authentication
```python
# JWT Token authentication
from rest_framework_simplejwt.authentication import JWTAuthentication

class SecureAPIView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        # Validate API key
        api_key = request.headers.get('X-API-Key')
        if not validate_api_key(api_key):
            return Response({'error': 'Invalid API key'}, status=401)
```

### CORS Security
```python
# Restrictive CORS settings
CORS_ALLOWED_ORIGINS = [
    "https://yourdomain.com",
    "https://www.yourdomain.com",
]
CORS_ALLOW_CREDENTIALS = True
CORS_ALLOWED_HEADERS = [
    'accept',
    'accept-encoding',
    'authorization',
    'content-type',
    'dnt',
    'origin',
    'user-agent',
    'x-csrftoken',
    'x-requested-with',
]
```

## Database Security

### Connection Security
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': os.environ.get('DB_NAME'),
        'USER': os.environ.get('DB_USER'),
        'PASSWORD': os.environ.get('DB_PASSWORD'),
        'HOST': os.environ.get('DB_HOST'),
        'PORT': os.environ.get('DB_PORT'),
        'OPTIONS': {
            'sslmode': 'require',  # Force SSL
        },
    }
}
```

### Query Security
```python
# Good - Use select_related to prevent N+1 queries
students = Student.objects.select_related('class', 'section').all()

# Good - Limit query results
students = Student.objects.all()[:100]

# Good - Use database constraints
class Student(models.Model):
    email = models.EmailField(unique=True)  # Database-level constraint
    age = models.IntegerField(validators=[MinValueValidator(5), MaxValueValidator(100)])
```

## Logging & Monitoring

### Security Logging
```python
import logging
security_logger = logging.getLogger('security')

def login_view(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    
    user = authenticate(username=username, password=password)
    if user:
        login(request, user)
        security_logger.info(f"Successful login: {username} from {request.META.get('REMOTE_ADDR')}")
    else:
        security_logger.warning(f"Failed login attempt: {username} from {request.META.get('REMOTE_ADDR')}")
```

### Audit Trail
```python
class AuditLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=100)
    model_name = models.CharField(max_length=100)
    object_id = models.CharField(max_length=100)
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField()
    user_agent = models.TextField()

def log_user_action(user, action, obj, request):
    AuditLog.objects.create(
        user=user,
        action=action,
        model_name=obj.__class__.__name__,
        object_id=str(obj.pk),
        ip_address=request.META.get('REMOTE_ADDR'),
        user_agent=request.META.get('HTTP_USER_AGENT', '')
    )
```

## Environment Security

### Environment Variables
```python
# Good - Use environment variables for secrets
SECRET_KEY = os.environ.get('SECRET_KEY')
DATABASE_PASSWORD = os.environ.get('DATABASE_PASSWORD')

# Never - Hardcode secrets
SECRET_KEY = 'hardcoded-secret-key'  # DANGEROUS
```

### Production Settings
```python
# Production security settings
DEBUG = False
ALLOWED_HOSTS = ['yourdomain.com', 'www.yourdomain.com']

# Security headers
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'
SECURE_REFERRER_POLICY = 'strict-origin-when-cross-origin'
```

## Security Testing

### Regular Security Audits
```python
# Security test examples
class SecurityTestCase(TestCase):
    def test_sql_injection_protection(self):
        malicious_input = "'; DROP TABLE students; --"
        response = self.client.post('/search/', {'query': malicious_input})
        self.assertEqual(response.status_code, 200)
        # Verify table still exists
        self.assertTrue(Student.objects.exists())
    
    def test_xss_protection(self):
        malicious_script = "<script>alert('XSS')</script>"
        response = self.client.post('/comment/', {'content': malicious_script})
        self.assertNotContains(response, '<script>')
```

## Security Checklist

### Pre-Deployment Security Review
- [ ] All inputs validated and sanitized
- [ ] Authentication and authorization implemented
- [ ] HTTPS enforced in production
- [ ] Sensitive data encrypted
- [ ] File uploads secured
- [ ] Rate limiting implemented
- [ ] Security headers configured
- [ ] Error handling doesn't leak information
- [ ] Logging and monitoring in place
- [ ] Dependencies updated and scanned
- [ ] Security tests passing
- [ ] Environment variables secured

### Regular Security Maintenance
- [ ] Update dependencies monthly
- [ ] Review access permissions quarterly
- [ ] Audit logs regularly
- [ ] Penetration testing annually
- [ ] Security training for team
- [ ] Incident response plan updated
- [ ] Backup and recovery tested

Remember: Security is not a one-time implementation but an ongoing process that requires constant vigilance and updates.