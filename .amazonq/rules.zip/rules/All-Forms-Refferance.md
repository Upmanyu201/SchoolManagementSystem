 add_student.html - Professional Form
Modern gradient background (blue to purple)

Icon-enhanced labels for each field

Organized sections with visual separation

Enhanced file upload areas with drag-and-drop styling

Real-time image preview with animations

Professional document upload section

Responsive grid layout

Interactive hover effects

Loading states for form submission

Enhanced focus effects for better UX

🎨 Key Features:
Gradient backgrounds and modern color schemes

Smooth animations and transitions

These above chages are so so good so always this forms page will be referance form those form pages.

Code:
{% extends 'base.html' %}
{% load i18n %}
{% load static %}

{% block content %}
<div class="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 py-8">
    <div class="container mx-auto px-4">
        <div class="max-w-5xl mx-auto">
            <!-- Header Card -->
            <div class="bg-white rounded-2xl shadow-xl p-6 mb-8 border border-blue-200">
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <div class="w-12 h-12 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mr-4">
                            <i class="fas fa-user-graduate text-white text-xl"></i>
                        </div>
                        <div>
                            <h1 class="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-800 bg-clip-text text-transparent">
                                {% if form.instance.id %}{% trans "Edit Student" %}{% else %}{% trans "Add New Student" %}{% endif %}
                            </h1>
                            <p class="text-gray-600 mt-1">{% trans "Fill in the student information below" %}</p>
                        </div>
                    </div>
                    <a href="{% url 'students:student_list' %}" 
                       class="btn btn-secondary px-4 py-2 rounded-xl transition-all duration-300 hover:scale-105">
                        <i class="fas fa-arrow-left mr-2"></i>{% trans "Back to List" %}
                    </a>
                </div>
            </div>

            <!-- Messages -->
            {% if messages %}
            <div id="form-messages" class="fixed top-4 right-4 z-50 space-y-2">
                {% for message in messages %}
                <div class="{% if message.tags == 'success' %}bg-green-500{% elif message.tags == 'error' %}bg-red-500{% else %}bg-blue-500{% endif %} text-white p-4 rounded-xl shadow-lg animate-slide-in">
                    <div class="flex items-center">
                        <i class="fas {% if message.tags == 'success' %}fa-check-circle{% elif message.tags == 'error' %}fa-exclamation-circle{% else %}fa-info-circle{% endif %} mr-3"></i>
                        <span class="font-medium">{{ message }}</span>
                    </div>
                </div>
                {% endfor %}
            </div>
            {% endif %}

            <!-- Form Errors -->
            {% if form.errors %}
            <div class="bg-gradient-to-r from-red-50 to-pink-50 border-2 border-red-200 rounded-2xl p-6 mb-8">
                <div class="flex items-center mb-4">
                    <div class="w-10 h-10 bg-red-500 rounded-full flex items-center justify-center mr-3">
                        <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                    <h3 class="text-red-800 font-bold text-lg">{% trans "Please correct the following errors" %}:</h3>
                </div>
                <ul class="space-y-2">
                    {% for field, errors in form.errors.items %}
                    <li class="bg-white rounded-lg p-3 border border-red-200">
                        <strong class="text-red-700">{{ field|capfirst }}:</strong> 
                        <span class="text-red-600">{{ errors|join:", " }}</span>
                    </li>
                    {% endfor %}
                </ul>
            </div>
            {% endif %}

            <!-- Student Form -->
            <div class="bg-white rounded-2xl shadow-2xl overflow-hidden border border-gray-200">
                <div class="bg-gradient-to-r from-blue-500 to-indigo-600 p-6">
                    <h2 class="text-white text-xl font-bold flex items-center">
                        <i class="fas fa-edit mr-3"></i>{% trans "Student Information Form" %}
                    </h2>
                </div>
                <form method="POST" enctype="multipart/form-data" class="p-8">
                    {% csrf_token %}

                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <!-- Left Column -->
                        <div class="space-y-6">
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-id-badge mr-2 text-blue-500"></i>{% trans "Admission Number" %}*
                                </label>
                                <div class="relative">
                                    {{ form.admission_number }}
                                    <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                        <i class="fas fa-hashtag text-gray-400"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-user mr-2 text-green-500"></i>{% trans "First Name" %}*
                                </label>
                                {{ form.first_name }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-user mr-2 text-green-500"></i>{% trans "Last Name" %}*
                                </label>
                                {{ form.last_name }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-male mr-2 text-blue-500"></i>{% trans "Father's Name" %}
                                </label>
                                {{ form.father_name }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-female mr-2 text-pink-500"></i>{% trans "Mother's Name" %}
                                </label>
                                {{ form.mother_name }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-birthday-cake mr-2 text-purple-500"></i>{% trans "Date of Birth" %}
                                </label>
                                {{ form.date_of_birth }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-calendar-plus mr-2 text-indigo-500"></i>{% trans "Date of Admission" %}
                                </label>
                                {{ form.date_of_admission }}
                            </div>
                        </div>

                        <!-- Right Column -->
                        <div class="space-y-6">
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-school mr-2 text-blue-500"></i>{% trans "Class" %}*
                                </label>
                                {{ form.student_class }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-layer-group mr-2 text-indigo-500"></i>{% trans "Section" %}
                                </label>
                                {{ form.student_section }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-venus-mars mr-2 text-purple-500"></i>{% trans "Gender" %}
                                </label>
                                {{ form.gender }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-pray mr-2 text-orange-500"></i>{% trans "Religion" %}
                                </label>
                                {{ form.religion }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-users mr-2 text-teal-500"></i>{% trans "Caste Category" %}
                                </label>
                                {{ form.caste_category }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-tint mr-2 text-red-500"></i>{% trans "Blood Group" %}
                                </label>
                                {{ form.blood_group }}
                            </div>
                        </div>
                    </div>

                    <!-- Contact Information -->
                    <div class="mt-8 grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <div class="form-group">
                            <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                <i class="fas fa-phone mr-2 text-green-500"></i>{% trans "Mobile Number" %}
                            </label>
                            {{ form.mobile_number }}
                        </div>
                        <div class="form-group">
                            <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                <i class="fas fa-envelope mr-2 text-blue-500"></i>{% trans "Email" %}
                            </label>
                            {{ form.email }}
                        </div>
                    </div>

                    <!-- Full Width Fields -->
                    <div class="mt-8 space-y-6">
                        <div class="form-group">
                            <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                <i class="fas fa-map-marker-alt mr-2 text-red-500"></i>{% trans "Address" %}
                            </label>
                            {{ form.address }}
                        </div>
                        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-id-card mr-2 text-indigo-500"></i>{% trans "Aadhaar Number" %}
                                </label>
                                {{ form.aadhaar_number }}
                            </div>
                            <div class="form-group">
                                <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                    <i class="fas fa-barcode mr-2 text-purple-500"></i>{% trans "PEN Number" %}
                                </label>
                                {{ form.pen_number }}
                            </div>
                        </div>
                    </div>

                    <!-- Document Uploads Section -->
                    <div class="mt-8">
                        <div class="bg-gradient-to-r from-gray-50 to-gray-100 rounded-xl p-6 border border-gray-200">
                            <h3 class="text-lg font-bold text-gray-800 mb-6 flex items-center">
                                <i class="fas fa-upload mr-3 text-blue-500"></i>{% trans "Document Uploads" %}
                            </h3>
                            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                                <!-- Student Photo -->
                                <div class="form-group">
                                    <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                        <i class="fas fa-camera mr-2 text-green-500"></i>{% trans "Student Photo" %}
                                    </label>
                                    <div class="relative">
                                        <input type="file" id="student_photo" name="student_image" 
                                               class="block w-full text-sm text-gray-500 file:mr-4 file:py-3 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 cursor-pointer border-2 border-dashed border-gray-300 rounded-xl p-4 hover:border-blue-400 transition-colors">
                                    </div>
                                    <div class="mt-4 flex items-center justify-center">
                                        <img id="photo_preview"
                                            src="{% if form.instance.student_image %}{{ form.instance.student_image.url }}{% else %}{% static 'images/default-profile.png' %}{% endif %}"
                                            class="w-20 h-20 rounded-full border-4 border-blue-200 object-cover shadow-lg">
                                    </div>
                                    <p class="text-xs text-gray-500 text-center mt-2">JPEG or PNG, max 2MB</p>
                                </div>

                                <!-- Aadhar Card -->
                                <div class="form-group">
                                    <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                        <i class="fas fa-id-card mr-2 text-orange-500"></i>{% trans "Aadhar Card" %}
                                    </label>
                                    <div class="relative">
                                        {{ form.aadhar_card }}
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">PDF format only</p>
                                </div>

                                <!-- Transfer Certificate -->
                                <div class="form-group">
                                    <label class="block text-gray-700 font-semibold mb-3 flex items-center">
                                        <i class="fas fa-certificate mr-2 text-purple-500"></i>{% trans "Transfer Certificate" %}
                                    </label>
                                    <div class="relative">
                                        {{ form.transfer_certificate }}
                                    </div>
                                    <p class="text-xs text-gray-500 mt-2">PDF format only</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="mt-10 text-center">
                        <button type="submit" name="preview" value="true"
                                class="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 text-white font-bold py-4 px-12 rounded-2xl transition-all duration-300 transform hover:scale-105 hover:shadow-xl">
                            <i class="fas fa-save mr-3"></i>
                            {% if form.instance.id %}{% trans "Update Student" %}{% else %}{% trans "Add Student" %}{% endif %}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
// Image Preview
document.addEventListener('DOMContentLoaded', function() {
    const photoInput = document.getElementById('student_photo');
    const photoPreview = document.getElementById('photo_preview');
    
    if (photoInput) {
        photoInput.addEventListener('change', function(event) {
            if (event.target.files && event.target.files[0]) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    photoPreview.src = e.target.result;
                    photoPreview.classList.add('animate-pulse');
                    setTimeout(() => photoPreview.classList.remove('animate-pulse'), 1000);
                };
                reader.readAsDataURL(event.target.files[0]);
            }
        });
    }
    
    // Auto-hide messages
    const messages = document.getElementById('form-messages');
    if (messages) {
        setTimeout(() => {
            messages.style.opacity = '0';
            messages.style.transform = 'translateX(100%)';
            setTimeout(() => messages.remove(), 500);
        }, 5000);
    }
    
    // Form validation enhancement
    const form = document.querySelector('form');
    const submitBtn = form.querySelector('button[type="submit"]');
    
    form.addEventListener('submit', function() {
        submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin mr-3"></i>Processing...';
        submitBtn.disabled = true;
    });
    
    // Add focus effects to form inputs
    const inputs = document.querySelectorAll('input, select, textarea');
    inputs.forEach(input => {
        input.addEventListener('focus', function() {
            this.parentElement.classList.add('ring-2', 'ring-blue-300');
        });
        
        input.addEventListener('blur', function() {
            this.parentElement.classList.remove('ring-2', 'ring-blue-300');
        });
    });
});
</script>

<style>
@keyframes slide-in {
    from {
        opacity: 0;
        transform: translateX(100%);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

.animate-slide-in {
    animation: slide-in 0.3s ease-out;
}

/* Enhanced form styling */
.form-input, .form-select, .form-textarea {
    @apply w-full px-4 py-3 border-2 border-gray-200 rounded-xl focus:border-blue-400 focus:ring-0 transition-all duration-300 bg-white;
}

.form-input:focus, .form-select:focus, .form-textarea:focus {
    @apply shadow-lg transform scale-[1.02];
}

/* File input styling */
input[type="file"] {
    @apply border-2 border-dashed border-gray-300 rounded-xl p-4 hover:border-blue-400 transition-colors cursor-pointer;
}

/* Button hover effects */
.btn {
    @apply transition-all duration-300 transform hover:scale-105;
}

/* Gradient text */
.gradient-text {
    @apply bg-gradient-to-r from-blue-600 to-indigo-800 bg-clip-text text-transparent;
}
</style>
{% endblock %}

{% block extra_css %}
<style>
/* Additional custom styles for better form appearance */
.form-group {
    position: relative;
}

.form-group label {
    transition: all 0.3s ease;
}

.form-group:hover label {
    color: #3B82F6;
}

/* Animated borders */
.form-input, .form-select, .form-textarea {
    position: relative;
    background: linear-gradient(145deg, #ffffff, #f8fafc);
    box-shadow: inset 2px 2px 5px #e2e8f0, inset -2px -2px 5px #ffffff;
}

.form-input:focus, .form-select:focus, .form-textarea:focus {
    background: #ffffff;
    box-shadow: 0 0 20px rgba(59, 130, 246, 0.15);
}

/* Card hover effects */
.bg-white {
    transition: all 0.3s ease;
}

.bg-white:hover {
    box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
}
</style>
{% endblock %}
