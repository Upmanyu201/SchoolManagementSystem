# Development Tools Organization Rule

Always create files for development tasks in the appropriate `dev_tools/` subfolder:

- **Testing files** → `dev_tools/testing/<name-of-CurrentWorkingApp>/`
- **Debug scripts** → `dev_tools/debugging/<name-of-CurrentWorkingApp>/` 
- **Documentation** → `dev_tools/docs/<name-of-CurrentWorkingApp>/`
- **Utility scripts** → `dev_tools/scripts/<name-of-CurrentWorkingApp>/`
- **Reports** → `dev_tools/reports/<name-of-CurrentWorkingApp>/`
- **Security files** → `dev_tools/security/<name-of-CurrentWorkingApp>/`
- **Config files** → `dev_tools/config/<name-of-CurrentWorkingApp>`
- **Task lists** → `dev_tools/todo/<name-of-CurrentWorkingApp>/`
- **Development logs** → `dev_tools/diary/<name-of-CurrentWorkingApp>/`
- **Work summaries** → `dev_tools/work_reports/<name-of-CurrentWorkingApp>/`
- **MCP Server** → "dev_tools/mcp/<name of mcp server>"

Keep the main project directory clean by organizing all development-related files in their designated folders.