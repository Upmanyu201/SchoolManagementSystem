# Web Application Development Rules

## 1. Architecture & Structure

### MVC/MVT Pattern
- **Model**: Data structure and database logic
- **View**: User interface and presentation
- **Controller/Template**: Business logic and request handling

### Separation of Concerns
- Keep HTML, CSS, and JavaScript separate
- Separate frontend from backend logic
- Use modular, reusable components

## 2. Security Fundamentals

### Input Validation
```python
# Always validate user input
def validate_phone_number(value):
    if not re.match(r'^\d{10}$', value):
        raise ValidationError('Invalid phone number')
```

### Authentication & Authorization
- Implement user login/logout
- Use session management
- Role-based access control
- CSRF protection

### Data Protection
- SQL injection prevention (use ORM)
- XSS protection (escape output)
- Secure file uploads
- HTTPS for production

## 3. Database Design

### Normalization
- Avoid data duplication
- Use foreign keys for relationships
- Index frequently queried fields

### Data Integrity
```python
class Student(models.Model):
    admission_number = models.CharField(unique=True)  # Unique constraint
    email = models.EmailField()  # Built-in validation
```

## 4. User Experience (UX)

### Responsive Design
- Mobile-first approach
- Flexible layouts (CSS Grid/Flexbox)
- Touch-friendly interfaces

### Performance
- Minimize HTTP requests
- Optimize images and assets
- Use caching strategies
- Lazy loading for large datasets

### Accessibility
- Semantic HTML elements
- Alt text for images
- Keyboard navigation support
- Screen reader compatibility

## 5. Error Handling

### Graceful Degradation
```python
try:
    # Database operation
    student.save()
except ValidationError as e:
    # Show user-friendly error message
    messages.error(request, "Please check your input")
```

### User Feedback
- Clear error messages
- Success confirmations
- Loading states
- Form validation feedback

## 6. Code Organization

### DRY Principle (Don't Repeat Yourself)
- Reusable functions and components
- Template inheritance
- Shared utilities

### Clean Code
```python
# Good: Descriptive function names
def calculate_student_due_amount(student):
    return total_fees - total_paid

# Bad: Unclear naming
def calc(s):
    return x - y
```

## 7. Testing Strategy

### Automated Testing
- Unit tests for individual functions
- Integration tests for workflows
- User acceptance testing

### Manual Testing
- Cross-browser compatibility
- Different screen sizes
- Edge cases and error scenarios

## 8. Development Workflow

### Version Control
- Use Git for source code management
- Meaningful commit messages
- Branch-based development

### Environment Management
- Development, staging, production environments
- Environment-specific configurations
- Dependency management

## 9. Performance Optimization

### Frontend
- Minify CSS/JavaScript
- Compress images
- Use CDNs for static assets
- Browser caching

### Backend
- Database query optimization
- Pagination for large datasets
- Background task processing
- Server-side caching

## 10. Deployment & Maintenance

### Production Readiness
- Environment variables for secrets
- Error logging and monitoring
- Backup strategies
- SSL certificates

### Scalability
- Load balancing
- Database optimization
- Horizontal scaling considerations

## Example Implementation (Django)

```python
# models.py - Data structure
class Student(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)

# views.py - Business logic
def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student added successfully')
            return redirect('student_list')
    else:
        form = StudentForm()
    return render(request, 'add_student.html', {'form': form})

# urls.py - Routing
urlpatterns = [
    path('students/add/', add_student, name='add_student'),
]
```

## Key Principles Summary

1. **Security First** - Always validate input and protect against common vulnerabilities
2. **User-Centered Design** - Focus on usability and accessibility
3. **Clean Architecture** - Maintain separation of concerns and modular design
4. **Performance Matters** - Optimize for speed and scalability
5. **Test Everything** - Implement comprehensive testing strategies
6. **Document Code** - Write clear, maintainable code with proper documentation
7. **Plan for Scale** - Design with growth and maintenance in mind
8. **Follow Standards** - Use established patterns and best practices
9. **Monitor & Maintain** - Implement logging, monitoring, and backup strategies
10. **Continuous Learning** - Stay updated with latest technologies and security practices

These rules ensure your web application is **secure**, **maintainable**, **scalable**, and provides a **good user experience**.