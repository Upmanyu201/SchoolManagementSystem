# Performance Optimization Rules

## Core Performance Principles

### 1. Measure Before Optimizing
- Profile application to identify bottlenecks
- Use metrics and monitoring tools
- Set performance benchmarks
- Focus on user-perceived performance

### 2. Optimize for Common Use Cases
- Identify most frequent operations
- Optimize critical user paths
- Cache frequently accessed data
- Minimize resource usage

### 3. Progressive Enhancement
- Start with basic functionality
- Add optimizations incrementally
- Monitor impact of changes
- Maintain fallback options

## Database Optimization

### Query Optimization
```python
# Bad - N+1 Query Problem
def get_students_with_classes():
    students = Student.objects.all()
    for student in students:
        print(f"{student.name} - {student.student_class.name}")  # N+1 queries

# Good - Use select_related for ForeignKey
def get_students_with_classes_optimized():
    students = Student.objects.select_related('student_class').all()
    for student in students:
        print(f"{student.name} - {student.student_class.name}")  # Single query

# Good - Use prefetch_related for ManyToMany/Reverse ForeignKey
def get_students_with_deposits():
    students = Student.objects.prefetch_related('fee_deposits').all()
    for student in students:
        deposits = student.fee_deposits.all()  # No additional queries
        print(f"{student.name} has {deposits.count()} deposits")

# Good - Complex prefetch with filtering
def get_students_with_recent_deposits():
    from django.db.models import Prefetch
    
    recent_deposits = FeeDeposit.objects.filter(
        payment_date__gte=timezone.now().date() - timedelta(days=30)
    )
    
    students = Student.objects.prefetch_related(
        Prefetch('fee_deposits', queryset=recent_deposits, to_attr='recent_deposits')
    ).all()
    
    for student in students:
        print(f"{student.name} has {len(student.recent_deposits)} recent deposits")
```

### Database Indexing
```python
# Good - Add database indexes for frequently queried fields
class Student(models.Model):
    admission_number = models.CharField(max_length=20, unique=True, db_index=True)
    email = models.EmailField(db_index=True)
    mobile_number = models.CharField(max_length=10, db_index=True)
    
    class Meta:
        indexes = [
            models.Index(fields=['first_name', 'last_name']),  # Composite index
            models.Index(fields=['student_class', 'student_section']),
            models.Index(fields=['-created_at']),  # For ordering
        ]

# Good - Partial indexes for specific conditions
class FeeDeposit(models.Model):
    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    is_verified = models.BooleanField(default=False)
    
    class Meta:
        indexes = [
            models.Index(fields=['student'], condition=models.Q(is_verified=False)),
            models.Index(fields=['payment_date'], condition=models.Q(amount__gt=1000)),
        ]
```

### Bulk Operations
```python
# Bad - Individual database operations
def update_student_fees_slow():
    students = Student.objects.all()
    for student in students:
        student.due_amount = calculate_due_amount(student)
        student.save()  # Individual UPDATE query for each student

# Good - Bulk operations
def update_student_fees_fast():
    students = Student.objects.all()
    updates = []
    
    for student in students:
        student.due_amount = calculate_due_amount(student)
        updates.append(student)
    
    # Single bulk UPDATE query
    Student.objects.bulk_update(updates, ['due_amount'], batch_size=1000)

# Good - Bulk create
def create_multiple_deposits():
    deposits = []
    for i in range(1000):
        deposits.append(FeeDeposit(
            student_id=i,
            amount=1000,
            payment_date=timezone.now().date()
        ))
    
    FeeDeposit.objects.bulk_create(deposits, batch_size=500)

# Good - Use database functions for calculations
from django.db.models import F, Sum, Case, When

def update_due_amounts_with_db_functions():
    # Calculate due amounts using database functions
    Student.objects.update(
        due_amount=F('total_fees') - F('total_paid')
    )
```

### Query Optimization Tools
```python
# Debug query performance
from django.db import connection
from django.conf import settings
import time

def debug_queries(func):
    """Decorator to debug database queries."""
    def wrapper(*args, **kwargs):
        if settings.DEBUG:
            start_queries = len(connection.queries)
            start_time = time.time()
            
            result = func(*args, **kwargs)
            
            end_time = time.time()
            end_queries = len(connection.queries)
            
            print(f"Function: {func.__name__}")
            print(f"Queries: {end_queries - start_queries}")
            print(f"Time: {end_time - start_time:.4f}s")
            
            # Show slow queries
            for query in connection.queries[start_queries:]:
                if float(query['time']) > 0.1:  # Queries taking >100ms
                    print(f"Slow query ({query['time']}s): {query['sql'][:100]}...")
            
            return result
        return func(*args, **kwargs)
    return wrapper

# Usage
@debug_queries
def get_student_report():
    return Student.objects.select_related('student_class').prefetch_related('fee_deposits').all()
```

## Caching Strategies

### Django Cache Framework
```python
# settings.py - Configure caching
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.redis.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
        },
        'KEY_PREFIX': 'school_mgmt',
        'TIMEOUT': 300,  # 5 minutes default
    }
}

# View-level caching
from django.views.decorators.cache import cache_page
from django.core.cache import cache

@cache_page(60 * 15)  # Cache for 15 minutes
def student_list_view(request):
    students = Student.objects.select_related('student_class').all()
    return render(request, 'students/list.html', {'students': students})

# Template fragment caching
# In template:
{% load cache %}
{% cache 500 student_list %}
    <!-- Expensive template rendering -->
    {% for student in students %}
        <div>{{ student.name }} - {{ student.student_class.name }}</div>
    {% endfor %}
{% endcache %}

# Low-level caching
def get_student_statistics():
    cache_key = 'student_statistics'
    stats = cache.get(cache_key)
    
    if stats is None:
        stats = {
            'total_students': Student.objects.count(),
            'total_fees_collected': FeeDeposit.objects.aggregate(Sum('amount'))['amount__sum'],
            'pending_fees': Student.objects.aggregate(Sum('due_amount'))['due_amount__sum'],
        }
        cache.set(cache_key, stats, 60 * 30)  # Cache for 30 minutes
    
    return stats

# Cache invalidation
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver

@receiver(post_save, sender=Student)
@receiver(post_delete, sender=Student)
def invalidate_student_cache(sender, **kwargs):
    cache.delete('student_statistics')
    cache.delete_many(['student_list', 'student_count'])
```

### Database Query Caching
```python
# Model-level caching
class Student(models.Model):
    # ... fields ...
    
    @property
    def total_fees_paid(self):
        cache_key = f'student_{self.id}_total_fees'
        total = cache.get(cache_key)
        
        if total is None:
            total = self.fee_deposits.aggregate(Sum('amount'))['amount__sum'] or 0
            cache.set(cache_key, total, 60 * 60)  # Cache for 1 hour
        
        return total
    
    def invalidate_cache(self):
        """Invalidate cached data for this student."""
        cache.delete(f'student_{self.id}_total_fees')
        cache.delete(f'student_{self.id}_due_amount')

# Cached manager
class CachedStudentManager(models.Manager):
    def get_active_students(self):
        cache_key = 'active_students'
        students = cache.get(cache_key)
        
        if students is None:
            students = list(self.filter(is_active=True).select_related('student_class'))
            cache.set(cache_key, students, 60 * 15)  # 15 minutes
        
        return students
```

## Frontend Optimization

### Static File Optimization
```python
# settings.py - Static file optimization
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# Compress static files
COMPRESS_ENABLED = True
COMPRESS_CSS_FILTERS = [
    'compressor.filters.css_default.CssAbsoluteFilter',
    'compressor.filters.cssmin.rCSSMinFilter',
]
COMPRESS_JS_FILTERS = [
    'compressor.filters.jsmin.JSMinFilter',
]

# CDN configuration
AWS_S3_CUSTOM_DOMAIN = 'your-cdn-domain.com'
STATIC_URL = f'https://{AWS_S3_CUSTOM_DOMAIN}/static/'
```

### JavaScript Optimization
```javascript
// Good - Lazy loading for large datasets
function loadStudentsLazily() {
    const container = document.getElementById('students-container');
    let page = 1;
    let loading = false;
    
    function loadPage() {
        if (loading) return;
        loading = true;
        
        fetch(`/api/students/?page=${page}`)
            .then(response => response.json())
            .then(data => {
                data.results.forEach(student => {
                    const element = createStudentElement(student);
                    container.appendChild(element);
                });
                
                page++;
                loading = false;
                
                // Load more if needed
                if (data.next && isNearBottom()) {
                    loadPage();
                }
            });
    }
    
    // Initial load
    loadPage();
    
    // Load more on scroll
    window.addEventListener('scroll', () => {
        if (isNearBottom() && !loading) {
            loadPage();
        }
    });
}

// Good - Debounce search input
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

const searchInput = document.getElementById('search');
const debouncedSearch = debounce(performSearch, 300);
searchInput.addEventListener('input', debouncedSearch);

// Good - Efficient DOM manipulation
function updateStudentList(students) {
    const fragment = document.createDocumentFragment();
    
    students.forEach(student => {
        const element = createStudentElement(student);
        fragment.appendChild(element);
    });
    
    // Single DOM update
    const container = document.getElementById('students-list');
    container.innerHTML = '';
    container.appendChild(fragment);
}
```

### Image Optimization
```python
# Image processing and optimization
from PIL import Image
import os

def optimize_student_image(image_path):
    """Optimize uploaded student images."""
    with Image.open(image_path) as img:
        # Resize if too large
        if img.width > 800 or img.height > 600:
            img.thumbnail((800, 600), Image.Resampling.LANCZOS)
        
        # Convert to RGB if necessary
        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')
        
        # Save with optimization
        optimized_path = image_path.replace('.jpg', '_optimized.jpg')
        img.save(optimized_path, 'JPEG', quality=85, optimize=True)
        
        return optimized_path

# Template - Responsive images
# In template:
<img src="{{ student.image.url }}" 
     srcset="{{ student.image.url }} 1x, 
             {{ student.image_2x.url }} 2x"
     alt="{{ student.name }}"
     loading="lazy"
     width="200" 
     height="150">
```

## Memory Optimization

### Memory-Efficient Queries
```python
# Bad - Loads all data into memory
def export_all_students():
    students = Student.objects.all()  # Loads everything
    return generate_csv(students)

# Good - Use iterator for large datasets
def export_all_students_memory_efficient():
    students = Student.objects.all().iterator(chunk_size=1000)
    return generate_csv_streaming(students)

# Good - Process in batches
def process_students_in_batches():
    batch_size = 1000
    offset = 0
    
    while True:
        students = Student.objects.all()[offset:offset + batch_size]
        if not students:
            break
        
        for student in students:
            process_student(student)
        
        offset += batch_size

# Memory monitoring
import psutil
import gc

def monitor_memory():
    """Monitor memory usage."""
    process = psutil.Process()
    memory_info = process.memory_info()
    
    print(f"RSS: {memory_info.rss / 1024 / 1024:.2f} MB")
    print(f"VMS: {memory_info.vms / 1024 / 1024:.2f} MB")
    
    # Force garbage collection
    collected = gc.collect()
    print(f"Garbage collected: {collected} objects")
```

### Connection Pooling
```python
# Database connection pooling
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.postgresql',
        'NAME': 'school_db',
        'USER': 'db_user',
        'PASSWORD': 'db_password',
        'HOST': 'localhost',
        'PORT': '5432',
        'OPTIONS': {
            'MAX_CONNS': 20,
            'MIN_CONNS': 5,
        },
        'CONN_MAX_AGE': 600,  # Connection reuse
    }
}

# Redis connection pooling
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': 'redis://127.0.0.1:6379/1',
        'OPTIONS': {
            'CONNECTION_POOL_KWARGS': {
                'max_connections': 50,
                'retry_on_timeout': True,
            }
        }
    }
}
```

## Performance Monitoring

### Application Performance Monitoring
```python
# Custom performance middleware
import time
import logging

performance_logger = logging.getLogger('performance')

class PerformanceMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        start_time = time.time()
        
        response = self.get_response(request)
        
        duration = time.time() - start_time
        
        # Log slow requests
        if duration > 1.0:  # Requests taking >1 second
            performance_logger.warning(
                f"Slow request: {request.method} {request.path} "
                f"took {duration:.2f}s"
            )
        
        # Add performance header
        response['X-Response-Time'] = f"{duration:.3f}s"
        
        return response

# Database query monitoring
from django.db import connection

class QueryCountMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        queries_before = len(connection.queries)
        
        response = self.get_response(request)
        
        queries_after = len(connection.queries)
        query_count = queries_after - queries_before
        
        # Log high query count
        if query_count > 10:
            performance_logger.warning(
                f"High query count: {request.path} "
                f"executed {query_count} queries"
            )
        
        response['X-Query-Count'] = str(query_count)
        
        return response
```

### Performance Metrics
```python
# Custom performance metrics
import time
from functools import wraps

def measure_performance(func):
    """Decorator to measure function performance."""
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        end_time = time.time()
        
        duration = end_time - start_time
        
        # Log performance metrics
        performance_logger.info(
            f"Function {func.__name__} took {duration:.4f}s"
        )
        
        # Store metrics for analysis
        store_performance_metric(func.__name__, duration)
        
        return result
    return wrapper

def store_performance_metric(function_name, duration):
    """Store performance metrics for analysis."""
    from django.core.cache import cache
    
    # Store in cache for real-time monitoring
    cache_key = f"perf_metrics_{function_name}"
    metrics = cache.get(cache_key, [])
    metrics.append({
        'timestamp': time.time(),
        'duration': duration
    })
    
    # Keep only last 100 measurements
    metrics = metrics[-100:]
    cache.set(cache_key, metrics, 3600)  # 1 hour

# Usage
@measure_performance
def calculate_student_fees(student):
    # Expensive calculation
    return complex_fee_calculation(student)
```

## Performance Testing

### Load Testing
```python
# Load testing with locust
from locust import HttpUser, task, between

class SchoolManagementUser(HttpUser):
    wait_time = between(1, 3)
    
    def on_start(self):
        """Login before starting tasks."""
        self.client.post("/login/", {
            "username": "testuser",
            "password": "testpass"
        })
    
    @task(3)
    def view_student_list(self):
        """Most common operation - view student list."""
        self.client.get("/students/")
    
    @task(2)
    def view_student_detail(self):
        """View individual student details."""
        self.client.get("/students/1/")
    
    @task(1)
    def add_student(self):
        """Less frequent operation - add student."""
        self.client.post("/students/add/", {
            "first_name": "Test",
            "last_name": "Student",
            "admission_number": f"TEST{self.user_id}",
            "email": f"test{self.user_id}@example.com",
            "mobile_number": "1234567890"
        })

# Run with: locust -f load_test.py --host=http://localhost:8000
```

### Performance Benchmarks
```python
# Performance benchmarks
import timeit
from django.test import TestCase

class PerformanceBenchmarkTest(TestCase):
    def setUp(self):
        # Create test data
        self.students = StudentFactory.create_batch(1000)
    
    def test_student_list_performance(self):
        """Benchmark student list query performance."""
        def query_students():
            return list(Student.objects.select_related('student_class').all())
        
        # Measure execution time
        execution_time = timeit.timeit(query_students, number=10) / 10
        
        # Assert performance requirement
        self.assertLess(execution_time, 0.1)  # Should complete in <100ms
    
    def test_bulk_update_performance(self):
        """Benchmark bulk update performance."""
        def bulk_update():
            students = Student.objects.all()
            for student in students:
                student.due_amount = 1000
            Student.objects.bulk_update(students, ['due_amount'], batch_size=500)
        
        execution_time = timeit.timeit(bulk_update, number=5) / 5
        
        # Should complete bulk update of 1000 records in <1 second
        self.assertLess(execution_time, 1.0)
```

## Performance Optimization Checklist

### Database Optimization
- [ ] Identify and fix N+1 query problems
- [ ] Add appropriate database indexes
- [ ] Use bulk operations for multiple records
- [ ] Optimize complex queries with EXPLAIN
- [ ] Implement database connection pooling
- [ ] Use database functions for calculations

### Caching Strategy
- [ ] Implement view-level caching
- [ ] Cache expensive database queries
- [ ] Use template fragment caching
- [ ] Set up cache invalidation strategy
- [ ] Monitor cache hit rates

### Frontend Optimization
- [ ] Minify and compress static files
- [ ] Implement lazy loading for images
- [ ] Use CDN for static assets
- [ ] Optimize JavaScript execution
- [ ] Implement responsive images

### Memory Management
- [ ] Use iterators for large datasets
- [ ] Process data in batches
- [ ] Monitor memory usage
- [ ] Implement proper garbage collection
- [ ] Optimize file uploads

### Monitoring & Testing
- [ ] Set up performance monitoring
- [ ] Create performance benchmarks
- [ ] Implement load testing
- [ ] Monitor database query performance
- [ ] Track application metrics

Remember: Performance optimization is an ongoing process. Regularly monitor, measure, and optimize based on real-world usage patterns and user feedback.