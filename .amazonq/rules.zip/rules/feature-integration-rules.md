# Feature Integration Rules

## Core Principles

### 1. Backward Compatibility
- New features should not break existing functionality
- Maintain API compatibility when possible
- Use feature flags for gradual rollouts
- Provide migration paths for breaking changes

### 2. Modular Integration
- Features should be self-contained modules
- Minimize dependencies on existing code
- Use dependency injection for loose coupling
- Follow established patterns and conventions

### 3. Incremental Development
- Break large features into smaller components
- Implement and test incrementally
- Use feature branches for development
- Regular integration with main branch

## Pre-Integration Analysis

### 1. Impact Assessment
```python
# Before adding new feature, analyze:
# - Which existing models will be affected?
# - What new database tables are needed?
# - Which views/URLs need modification?
# - What new permissions are required?
# - How will this affect existing APIs?

# Example: Adding messaging feature
IMPACT_ANALYSIS = {
    'models': ['User', 'Student', 'Teacher'],  # Models to extend
    'new_models': ['Message', 'MessageLog', 'NotificationSettings'],
    'views': ['dashboard', 'student_detail'],  # Views to modify
    'new_views': ['message_list', 'send_message'],
    'permissions': ['send_message', 'view_messages'],
    'apis': ['student_api'],  # APIs to extend
    'dependencies': ['twilio', 'celery']  # New dependencies
}
```

### 2. Database Design
```python
# Good - Plan database changes carefully
class Message(BaseModel):
    """New model for messaging feature."""
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_messages')
    content = models.TextField()
    message_type = models.CharField(max_length=20, choices=MESSAGE_TYPE_CHOICES)
    is_read = models.BooleanField(default=False)
    
    class Meta:
        indexes = [
            models.Index(fields=['recipient', 'is_read']),
            models.Index(fields=['sender', 'created_at']),
        ]

# Extend existing models carefully
class Student(BaseModel):
    # Existing fields...
    
    # New field for messaging feature
    notification_preferences = models.JSONField(default=dict, blank=True)
    
    def get_unread_message_count(self):
        """New method for messaging feature."""
        return self.received_messages.filter(is_read=False).count()
```

## Step-by-Step Integration Process

### Step 1: Create Feature Branch
```bash
# Create feature branch
git checkout -b feature/messaging-system
git push -u origin feature/messaging-system
```

### Step 2: Database Migrations
```python
# Create migrations for new models
python manage.py makemigrations messaging
python manage.py migrate

# For existing model changes
python manage.py makemigrations students --name add_notification_preferences
python manage.py migrate
```

### Step 3: Implement Core Models
```python
# messaging/models.py
from django.db import models
from core.models import BaseModel

class Message(BaseModel):
    """Core message model."""
    # Implementation here
    pass

class MessageTemplate(BaseModel):
    """Template for common messages."""
    name = models.CharField(max_length=100)
    content = models.TextField()
    variables = models.JSONField(default=list)  # Template variables
    
    def render(self, context):
        """Render template with context variables."""
        return self.content.format(**context)
```

### Step 4: Create Services Layer
```python
# messaging/services.py
class MessagingService:
    """Service for messaging operations."""
    
    @staticmethod
    def send_message(sender, recipient, content, message_type='general'):
        """Send message to recipient."""
        # Validate permissions
        if not MessagingService._can_send_message(sender, recipient):
            raise PermissionError("Cannot send message to this recipient")
        
        # Create message
        message = Message.objects.create(
            sender=sender,
            recipient=recipient,
            content=content,
            message_type=message_type
        )
        
        # Send notification if enabled
        if recipient.notification_preferences.get('email_notifications', True):
            NotificationService.send_email_notification(recipient, message)
        
        return message
    
    @staticmethod
    def _can_send_message(sender, recipient):
        """Check if sender can message recipient."""
        # Implement permission logic
        return True
```

### Step 5: Integrate with Existing Views
```python
# Extend existing views to include messaging
class StudentDetailView(DetailView):
    model = Student
    template_name = 'students/student_detail.html'
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        
        # Add messaging context
        if hasattr(self.object, 'received_messages'):
            context['unread_messages'] = self.object.get_unread_message_count()
            context['recent_messages'] = self.object.received_messages.filter(
                is_read=False
            )[:5]
        
        return context
```

### Step 6: Create New Views
```python
# messaging/views.py
class MessageListView(LoginRequiredMixin, ListView):
    """List messages for current user."""
    model = Message
    template_name = 'messaging/message_list.html'
    paginate_by = 20
    
    def get_queryset(self):
        return Message.objects.filter(
            recipient=self.request.user
        ).select_related('sender').order_by('-created_at')

class SendMessageView(LoginRequiredMixin, CreateView):
    """Send new message."""
    model = Message
    form_class = MessageForm
    template_name = 'messaging/send_message.html'
    
    def form_valid(self, form):
        form.instance.sender = self.request.user
        return super().form_valid(form)
```

### Step 7: Update URL Configuration
```python
# messaging/urls.py
from django.urls import path
from . import views

app_name = 'messaging'

urlpatterns = [
    path('', views.MessageListView.as_view(), name='message_list'),
    path('send/', views.SendMessageView.as_view(), name='send_message'),
    path('api/send/', views.SendMessageAPIView.as_view(), name='api_send_message'),
]

# Update main urls.py
urlpatterns = [
    # Existing URLs...
    path('messaging/', include('messaging.urls')),
]
```

### Step 8: Template Integration
```html
<!-- Extend base template -->
<!-- messaging/templates/messaging/message_list.html -->
{% extends 'base.html' %}
{% load i18n %}

{% block content %}
<div class="messaging-container">
    <h2>{% trans "Messages" %}</h2>
    
    <!-- Integration with existing UI components -->
    <div class="card">
        <div class="card-header">
            <a href="{% url 'messaging:send_message' %}" class="btn btn-primary">
                {% trans "Send Message" %}
            </a>
        </div>
        
        <div class="card-body">
            {% for message in messages %}
                {% include 'messaging/includes/message_item.html' %}
            {% endfor %}
        </div>
    </div>
</div>
{% endblock %}

<!-- Update existing templates -->
<!-- students/templates/students/student_detail.html -->
{% if unread_messages > 0 %}
<div class="alert alert-info">
    <i class="fas fa-envelope"></i>
    You have {{ unread_messages }} unread message{{ unread_messages|pluralize }}.
    <a href="{% url 'messaging:message_list' %}">View Messages</a>
</div>
{% endif %}
```

### Step 9: API Integration
```python
# messaging/api_views.py
from rest_framework import generics, permissions
from .serializers import MessageSerializer

class MessageListAPIView(generics.ListAPIView):
    """API endpoint for listing messages."""
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        return Message.objects.filter(recipient=self.request.user)

class SendMessageAPIView(generics.CreateAPIView):
    """API endpoint for sending messages."""
    serializer_class = MessageSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def perform_create(self, serializer):
        serializer.save(sender=self.request.user)
```

### Step 10: Add Permissions
```python
# messaging/permissions.py
from django.contrib.auth.models import Permission
from django.contrib.contenttypes.models import ContentType

def create_messaging_permissions():
    """Create custom permissions for messaging."""
    content_type = ContentType.objects.get_for_model(Message)
    
    permissions = [
        ('send_message', 'Can send messages'),
        ('view_all_messages', 'Can view all messages'),
        ('delete_any_message', 'Can delete any message'),
    ]
    
    for codename, name in permissions:
        Permission.objects.get_or_create(
            codename=codename,
            name=name,
            content_type=content_type
        )
```

## Testing Integration

### Test New Features
```python
# messaging/tests.py
class MessagingIntegrationTest(TestCase):
    """Test messaging feature integration."""
    
    def setUp(self):
        self.user1 = User.objects.create_user('user1', 'user1@test.com', 'pass')
        self.user2 = User.objects.create_user('user2', 'user2@test.com', 'pass')
    
    def test_send_message_integration(self):
        """Test sending message through service."""
        message = MessagingService.send_message(
            sender=self.user1,
            recipient=self.user2,
            content="Test message"
        )
        
        self.assertEqual(message.sender, self.user1)
        self.assertEqual(message.recipient, self.user2)
        self.assertEqual(message.content, "Test message")
    
    def test_student_message_count(self):
        """Test integration with Student model."""
        student = Student.objects.create(
            first_name="John",
            last_name="Doe",
            admission_number="STU001"
        )
        
        # Send message to student's user account
        if hasattr(student, 'user'):
            MessagingService.send_message(
                sender=self.user1,
                recipient=student.user,
                content="Fee reminder"
            )
            
            self.assertEqual(student.user.get_unread_message_count(), 1)
```

### Test Backward Compatibility
```python
class BackwardCompatibilityTest(TestCase):
    """Ensure new features don't break existing functionality."""
    
    def test_existing_student_views_still_work(self):
        """Test that student views work with messaging integration."""
        student = Student.objects.create(
            first_name="Jane",
            last_name="Smith",
            admission_number="STU002"
        )
        
        response = self.client.get(f'/students/{student.id}/')
        self.assertEqual(response.status_code, 200)
        
        # Should not break even if messaging is not configured
        self.assertContains(response, student.first_name)
```

## Configuration Updates

### Settings Integration
```python
# Add to settings.py
INSTALLED_APPS = [
    # Existing apps...
    'messaging',  # New app
]

# Messaging-specific settings
MESSAGING_SETTINGS = {
    'MAX_MESSAGE_LENGTH': 1000,
    'ENABLE_EMAIL_NOTIFICATIONS': True,
    'ENABLE_SMS_NOTIFICATIONS': False,
    'MESSAGE_RETENTION_DAYS': 365,
}

# Update existing settings if needed
LOGGING['loggers']['messaging'] = {
    'handlers': ['file', 'console'],
    'level': 'INFO',
    'propagate': False,
}
```

### Environment Variables
```bash
# Add new environment variables
MESSAGING_EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
MESSAGING_SMS_PROVIDER=twilio
TWILIO_ACCOUNT_SID=your_account_sid
TWILIO_AUTH_TOKEN=your_auth_token
```

## Deployment Considerations

### Migration Strategy
```python
# Create data migration if needed
from django.db import migrations

def populate_notification_preferences(apps, schema_editor):
    """Populate default notification preferences for existing users."""
    User = apps.get_model('auth', 'User')
    for user in User.objects.all():
        if hasattr(user, 'student'):
            user.student.notification_preferences = {
                'email_notifications': True,
                'sms_notifications': False
            }
            user.student.save()

class Migration(migrations.Migration):
    dependencies = [
        ('messaging', '0001_initial'),
    ]
    
    operations = [
        migrations.RunPython(populate_notification_preferences),
    ]
```

### Feature Flags
```python
# Use feature flags for gradual rollout
FEATURE_FLAGS = {
    'MESSAGING_ENABLED': os.environ.get('MESSAGING_ENABLED', 'False').lower() == 'true',
    'SMS_NOTIFICATIONS': os.environ.get('SMS_NOTIFICATIONS', 'False').lower() == 'true',
}

# In templates
{% if 'MESSAGING_ENABLED'|feature_enabled %}
    <a href="{% url 'messaging:message_list' %}">Messages</a>
{% endif %}
```

## Integration Checklist

### Pre-Integration
- [ ] Impact analysis completed
- [ ] Database design reviewed
- [ ] Dependencies identified
- [ ] Feature branch created
- [ ] Tests planned

### During Integration
- [ ] Models created/updated
- [ ] Migrations applied
- [ ] Services implemented
- [ ] Views created/updated
- [ ] Templates integrated
- [ ] URLs configured
- [ ] Permissions added
- [ ] APIs implemented

### Post-Integration
- [ ] All tests passing
- [ ] Documentation updated
- [ ] Code reviewed
- [ ] Performance tested
- [ ] Security reviewed
- [ ] Deployment plan ready
- [ ] Rollback plan prepared

### Monitoring
- [ ] Logging configured
- [ ] Metrics tracked
- [ ] Error monitoring setup
- [ ] Performance monitoring active
- [ ] User feedback collected

Remember: Successful feature integration requires careful planning, incremental implementation, and thorough testing to ensure new functionality enhances rather than disrupts the existing system.