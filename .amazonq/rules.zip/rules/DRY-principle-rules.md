# DRY (Don't Repeat Yourself) Principle Rules

## Core DRY Principles

### 1. Single Source of Truth
- Every piece of knowledge should have a single, unambiguous representation
- Avoid duplicating logic, data, or configuration
- Centralize common functionality
- Use inheritance and composition effectively

### 2. Abstraction Over Duplication
- Extract common patterns into reusable components
- Create utility functions for repeated operations
- Use templates and mixins for shared behavior
- Implement base classes for common functionality

### 3. Configuration Management
- Centralize configuration in one place
- Use environment variables for different settings
- Avoid hardcoding values throughout the codebase
- Create configuration classes or modules

## Code-Level DRY Implementation

### Function Extraction
```python
# Bad - Repeated code
def calculate_student_monthly_fee(student):
    base_fee = 1000
    if student.class_name == "10":
        base_fee = 1200
    elif student.class_name == "11":
        base_fee = 1400
    elif student.class_name == "12":
        base_fee = 1600
    
    transport_fee = 0
    if student.transport_required:
        if student.distance < 5:
            transport_fee = 200
        elif student.distance < 10:
            transport_fee = 300
        else:
            transport_fee = 400
    
    return base_fee + transport_fee

def calculate_student_annual_fee(student):
    base_fee = 1000
    if student.class_name == "10":
        base_fee = 1200
    elif student.class_name == "11":
        base_fee = 1400
    elif student.class_name == "12":
        base_fee = 1600
    
    transport_fee = 0
    if student.transport_required:
        if student.distance < 5:
            transport_fee = 200
        elif student.distance < 10:
            transport_fee = 300
        else:
            transport_fee = 400
    
    return (base_fee + transport_fee) * 12

# Good - DRY implementation
class FeeCalculator:
    """Centralized fee calculation logic."""
    
    BASE_FEES = {
        "10": 1200,
        "11": 1400,
        "12": 1600,
    }
    
    TRANSPORT_FEES = [
        (5, 200),   # Distance < 5km
        (10, 300),  # Distance < 10km
        (float('inf'), 400)  # Distance >= 10km
    ]
    
    @classmethod
    def get_base_fee(cls, class_name):
        """Get base fee for a class."""
        return cls.BASE_FEES.get(class_name, 1000)
    
    @classmethod
    def get_transport_fee(cls, distance):
        """Get transport fee based on distance."""
        for max_distance, fee in cls.TRANSPORT_FEES:
            if distance < max_distance:
                return fee
        return 0
    
    @classmethod
    def calculate_monthly_fee(cls, student):
        """Calculate monthly fee for student."""
        base_fee = cls.get_base_fee(student.class_name)
        transport_fee = cls.get_transport_fee(student.distance) if student.transport_required else 0
        return base_fee + transport_fee
    
    @classmethod
    def calculate_annual_fee(cls, student):
        """Calculate annual fee for student."""
        return cls.calculate_monthly_fee(student) * 12
```

### Template Inheritance & Mixins
```python
# Good - Base classes to avoid repetition
class BaseModel(models.Model):
    """Base model with common fields and methods."""
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    is_active = models.BooleanField(default=True)
    
    class Meta:
        abstract = True
    
    def soft_delete(self):
        """Soft delete by setting is_active to False."""
        self.is_active = False
        self.save()
    
    def get_age_in_days(self):
        """Get age of record in days."""
        return (timezone.now() - self.created_at).days

class BaseViewMixin:
    """Base mixin for common view functionality."""
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['current_user'] = self.request.user
        context['current_time'] = timezone.now()
        return context
    
    def dispatch(self, request, *args, **kwargs):
        # Common logging for all views
        logger.info(f"View accessed: {self.__class__.__name__} by {request.user}")
        return super().dispatch(request, *args, **kwargs)

# Usage in models
class Student(BaseModel):
    name = models.CharField(max_length=100)
    # Inherits created_at, updated_at, is_active, soft_delete(), get_age_in_days()

class Teacher(BaseModel):
    name = models.CharField(max_length=100)
    # Inherits all BaseModel functionality

# Usage in views
class StudentListView(BaseViewMixin, ListView):
    model = Student
    # Inherits common context data and logging

class TeacherListView(BaseViewMixin, ListView):
    model = Teacher
    # Inherits common context data and logging
```

### Utility Functions & Helpers
```python
# Good - Centralized utility functions
class ValidationUtils:
    """Utility class for common validation functions."""
    
    @staticmethod
    def validate_phone_number(phone):
        """Validate phone number format."""
        pattern = r'^\+?1?\d{9,15}$'
        return re.match(pattern, phone) is not None
    
    @staticmethod
    def validate_email(email):
        """Validate email format."""
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return re.match(pattern, email) is not None
    
    @staticmethod
    def validate_admission_number(admission_number):
        """Validate admission number format."""
        pattern = r'^[A-Z]{2,3}\d{3,6}$'
        return re.match(pattern, admission_number) is not None

class DateUtils:
    """Utility class for date operations."""
    
    @staticmethod
    def get_academic_year(date=None):
        """Get academic year for a given date."""
        if date is None:
            date = timezone.now().date()
        
        if date.month >= 4:  # April onwards
            return f"{date.year}-{date.year + 1}"
        else:
            return f"{date.year - 1}-{date.year}"
    
    @staticmethod
    def get_age(birth_date):
        """Calculate age from birth date."""
        today = timezone.now().date()
        return today.year - birth_date.year - ((today.month, today.day) < (birth_date.month, birth_date.day))

class MessageUtils:
    """Utility class for message formatting."""
    
    @staticmethod
    def format_currency(amount):
        """Format amount as currency."""
        return f"₹{amount:,.2f}"
    
    @staticmethod
    def format_phone_display(phone):
        """Format phone number for display."""
        if len(phone) == 10:
            return f"{phone[:3]}-{phone[3:6]}-{phone[6:]}"
        return phone
    
    @staticmethod
    def truncate_text(text, max_length=50):
        """Truncate text with ellipsis."""
        return text[:max_length] + "..." if len(text) > max_length else text

# Usage across the application
# In forms.py
def clean_mobile_number(self):
    mobile = self.cleaned_data['mobile_number']
    if not ValidationUtils.validate_phone_number(mobile):
        raise ValidationError("Invalid phone number format")
    return mobile

# In models.py
def get_student_age(self):
    return DateUtils.get_age(self.date_of_birth)

# In templates
{{ student.fee_amount|format_currency }}
```

## Template-Level DRY

### Base Templates
```html
<!-- base.html - Master template -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{% block title %}School Management System{% endblock %}</title>
    
    <!-- Common CSS -->
    <link rel="stylesheet" href="{% static 'css/base.css' %}">
    {% block extra_css %}{% endblock %}
</head>
<body>
    <!-- Common Header -->
    {% include 'components/header.html' %}
    
    <!-- Main Content -->
    <main class="main-content">
        {% block content %}{% endblock %}
    </main>
    
    <!-- Common Footer -->
    {% include 'components/footer.html' %}
    
    <!-- Common JavaScript -->
    <script src="{% static 'js/base.js' %}"></script>
    {% block extra_js %}{% endblock %}
</body>
</html>

<!-- form_base.html - Form-specific base -->
{% extends 'base.html' %}

{% block content %}
<div class="form-container">
    <div class="form-header">
        <h1>{% block form_title %}{% endblock %}</h1>
        <p class="form-description">{% block form_description %}{% endblock %}</p>
    </div>
    
    {% if messages %}
        {% include 'components/messages.html' %}
    {% endif %}
    
    <form method="post" class="form" {% block form_attrs %}{% endblock %}>
        {% csrf_token %}
        {% block form_content %}{% endblock %}
        
        <div class="form-actions">
            {% block form_actions %}
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="{% block cancel_url %}{% endblock %}" class="btn btn-secondary">Cancel</a>
            {% endblock %}
        </div>
    </form>
</div>
{% endblock %}
```

### Reusable Template Components
```html
<!-- components/form_field.html -->
<div class="form-group {% if field.errors %}form-group-error{% endif %}">
    <label for="{{ field.id_for_label }}" class="form-label">
        {% if field.field.required %}<span class="required">*</span>{% endif %}
        {{ field.label }}
    </label>
    {{ field }}
    {% if field.help_text %}
        <div class="form-help">{{ field.help_text }}</div>
    {% endif %}
    {% if field.errors %}
        <div class="form-error">
            {% for error in field.errors %}{{ error }}{% endfor %}
        </div>
    {% endif %}
</div>

<!-- components/data_table.html -->
<div class="table-container">
    <table class="table">
        <thead>
            <tr>
                {% for header in table_headers %}
                    <th class="table-header">{{ header }}</th>
                {% endfor %}
            </tr>
        </thead>
        <tbody>
            {% for row in table_data %}
                <tr class="table-row">
                    {% for cell in row %}
                        <td class="table-cell">{{ cell }}</td>
                    {% endfor %}
                </tr>
            {% empty %}
                <tr>
                    <td colspan="{{ table_headers|length }}" class="table-empty">
                        No data available
                    </td>
                </tr>
            {% endfor %}
        </tbody>
    </table>
</div>

<!-- Usage in specific templates -->
<!-- student_form.html -->
{% extends 'form_base.html' %}

{% block form_title %}Add Student{% endblock %}
{% block form_description %}Enter student information below{% endblock %}

{% block form_content %}
    {% include 'components/form_field.html' with field=form.first_name %}
    {% include 'components/form_field.html' with field=form.last_name %}
    {% include 'components/form_field.html' with field=form.email %}
{% endblock %}

{% block cancel_url %}{% url 'students:list' %}{% endblock %}
```

### Template Tags & Filters
```python
# templatetags/common_tags.py
from django import template
from django.utils.safestring import mark_safe

register = template.Library()

@register.filter
def format_currency(value):
    """Format number as currency."""
    try:
        return f"₹{float(value):,.2f}"
    except (ValueError, TypeError):
        return value

@register.filter
def format_phone(value):
    """Format phone number for display."""
    if len(str(value)) == 10:
        phone = str(value)
        return f"{phone[:3]}-{phone[3:6]}-{phone[6:]}"
    return value

@register.inclusion_tag('components/status_badge.html')
def status_badge(status, label=None):
    """Render status badge component."""
    status_classes = {
        'active': 'badge-success',
        'inactive': 'badge-danger',
        'pending': 'badge-warning',
        'processing': 'badge-info',
    }
    
    return {
        'status': status,
        'label': label or status.title(),
        'css_class': status_classes.get(status.lower(), 'badge-secondary')
    }

@register.simple_tag
def get_setting(name, default=None):
    """Get setting value."""
    from django.conf import settings
    return getattr(settings, name, default)

# Usage in templates
{% load common_tags %}

{{ student.fee_amount|format_currency }}
{{ student.mobile_number|format_phone }}
{% status_badge student.status %}
{% get_setting 'SCHOOL_NAME' 'Default School' %}
```

## Configuration & Settings DRY

### Centralized Configuration
```python
# settings/base.py - Common settings
class BaseConfig:
    """Base configuration class."""
    
    # Application settings
    SCHOOL_NAME = "ABC School"
    ACADEMIC_YEAR_START_MONTH = 4
    DEFAULT_CURRENCY = "INR"
    DEFAULT_CURRENCY_SYMBOL = "₹"
    
    # Pagination settings
    DEFAULT_PAGE_SIZE = 20
    MAX_PAGE_SIZE = 100
    
    # File upload settings
    MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB
    ALLOWED_FILE_TYPES = ['.pdf', '.jpg', '.jpeg', '.png', '.doc', '.docx']
    
    # Email settings
    DEFAULT_FROM_EMAIL = "noreply@school.com"
    ADMIN_EMAIL = "admin@school.com"
    
    # SMS settings
    SMS_ENABLED = True
    SMS_PROVIDER = "twilio"
    
    # Fee settings
    LATE_FEE_PERCENTAGE = 5
    GRACE_PERIOD_DAYS = 7

# settings/development.py
from .base import BaseConfig

class DevelopmentConfig(BaseConfig):
    DEBUG = True
    SMS_ENABLED = False  # Disable SMS in development

# settings/production.py
from .base import BaseConfig

class ProductionConfig(BaseConfig):
    DEBUG = False
    SMS_ENABLED = True

# Usage throughout the application
from django.conf import settings

def calculate_late_fee(amount):
    return amount * (settings.LATE_FEE_PERCENTAGE / 100)

def is_within_grace_period(due_date):
    grace_period = timedelta(days=settings.GRACE_PERIOD_DAYS)
    return timezone.now().date() <= due_date + grace_period
```

### Environment-Based Configuration
```python
# config/environment.py
import os
from typing import Dict, Any

class EnvironmentConfig:
    """Environment-based configuration manager."""
    
    @staticmethod
    def get_database_config() -> Dict[str, Any]:
        """Get database configuration from environment."""
        return {
            'ENGINE': os.getenv('DB_ENGINE', 'django.db.backends.sqlite3'),
            'NAME': os.getenv('DB_NAME', 'db.sqlite3'),
            'USER': os.getenv('DB_USER', ''),
            'PASSWORD': os.getenv('DB_PASSWORD', ''),
            'HOST': os.getenv('DB_HOST', ''),
            'PORT': os.getenv('DB_PORT', ''),
        }
    
    @staticmethod
    def get_email_config() -> Dict[str, Any]:
        """Get email configuration from environment."""
        return {
            'EMAIL_BACKEND': os.getenv('EMAIL_BACKEND', 'django.core.mail.backends.console.EmailBackend'),
            'EMAIL_HOST': os.getenv('EMAIL_HOST', ''),
            'EMAIL_PORT': int(os.getenv('EMAIL_PORT', 587)),
            'EMAIL_USE_TLS': os.getenv('EMAIL_USE_TLS', 'True').lower() == 'true',
            'EMAIL_HOST_USER': os.getenv('EMAIL_HOST_USER', ''),
            'EMAIL_HOST_PASSWORD': os.getenv('EMAIL_HOST_PASSWORD', ''),
        }
    
    @staticmethod
    def get_sms_config() -> Dict[str, Any]:
        """Get SMS configuration from environment."""
        return {
            'TWILIO_ACCOUNT_SID': os.getenv('TWILIO_ACCOUNT_SID', ''),
            'TWILIO_AUTH_TOKEN': os.getenv('TWILIO_AUTH_TOKEN', ''),
            'TWILIO_PHONE_NUMBER': os.getenv('TWILIO_PHONE_NUMBER', ''),
        }

# Usage in settings.py
from config.environment import EnvironmentConfig

DATABASES = {'default': EnvironmentConfig.get_database_config()}
EMAIL_CONFIG = EnvironmentConfig.get_email_config()
globals().update(EMAIL_CONFIG)
```

## API & Serializer DRY

### Base Serializers
```python
# serializers/base.py
from rest_framework import serializers

class BaseModelSerializer(serializers.ModelSerializer):
    """Base serializer with common fields and methods."""
    
    created_at = serializers.DateTimeField(read_only=True)
    updated_at = serializers.DateTimeField(read_only=True)
    
    def validate(self, attrs):
        """Common validation logic."""
        # Add any common validation here
        return super().validate(attrs)
    
    def create(self, validated_data):
        """Common create logic."""
        instance = super().create(validated_data)
        # Add any common post-creation logic here
        return instance

class BaseUserRelatedSerializer(BaseModelSerializer):
    """Base serializer for models related to users."""
    
    created_by = serializers.StringRelatedField(read_only=True)
    updated_by = serializers.StringRelatedField(read_only=True)
    
    def create(self, validated_data):
        validated_data['created_by'] = self.context['request'].user
        return super().create(validated_data)
    
    def update(self, instance, validated_data):
        validated_data['updated_by'] = self.context['request'].user
        return super().update(instance, validated_data)

# Usage in specific serializers
class StudentSerializer(BaseUserRelatedSerializer):
    class Meta:
        model = Student
        fields = '__all__'
        # Inherits created_at, updated_at, created_by, updated_by

class TeacherSerializer(BaseUserRelatedSerializer):
    class Meta:
        model = Teacher
        fields = '__all__'
        # Inherits all base functionality
```

### Generic API Views
```python
# views/base.py
from rest_framework import generics, permissions
from rest_framework.response import Response

class BaseListCreateView(generics.ListCreateAPIView):
    """Base view for list and create operations."""
    
    permission_classes = [permissions.IsAuthenticated]
    
    def get_queryset(self):
        """Filter queryset based on user permissions."""
        queryset = super().get_queryset()
        
        # Apply user-based filtering
        if not self.request.user.is_superuser:
            # Add common filtering logic here
            pass
        
        return queryset
    
    def perform_create(self, serializer):
        """Add common create logic."""
        serializer.save(created_by=self.request.user)

class BaseRetrieveUpdateDestroyView(generics.RetrieveUpdateDestroyAPIView):
    """Base view for retrieve, update, and delete operations."""
    
    permission_classes = [permissions.IsAuthenticated]
    
    def perform_update(self, serializer):
        """Add common update logic."""
        serializer.save(updated_by=self.request.user)

# Usage in specific views
class StudentListCreateView(BaseListCreateView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    # Inherits all base functionality

class StudentRetrieveUpdateDestroyView(BaseRetrieveUpdateDestroyView):
    queryset = Student.objects.all()
    serializer_class = StudentSerializer
    # Inherits all base functionality
```

## JavaScript/Frontend DRY

### Reusable JavaScript Modules
```javascript
// utils/api.js - Centralized API utilities
class APIClient {
    constructor(baseURL = '/api/') {
        this.baseURL = baseURL;
        this.defaultHeaders = {
            'Content-Type': 'application/json',
            'X-CSRFToken': this.getCSRFToken()
        };
    }
    
    getCSRFToken() {
        return document.querySelector('[name=csrfmiddlewaretoken]')?.value || '';
    }
    
    async request(endpoint, options = {}) {
        const url = `${this.baseURL}${endpoint}`;
        const config = {
            headers: { ...this.defaultHeaders, ...options.headers },
            ...options
        };
        
        try {
            const response = await fetch(url, config);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            return await response.json();
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }
    
    get(endpoint) {
        return this.request(endpoint, { method: 'GET' });
    }
    
    post(endpoint, data) {
        return this.request(endpoint, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }
    
    put(endpoint, data) {
        return this.request(endpoint, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }
    
    delete(endpoint) {
        return this.request(endpoint, { method: 'DELETE' });
    }
}

// utils/ui.js - Reusable UI utilities
class UIUtils {
    static showMessage(message, type = 'info') {
        const messageContainer = document.getElementById('messages');
        const messageElement = document.createElement('div');
        messageElement.className = `alert alert-${type}`;
        messageElement.textContent = message;
        
        messageContainer.appendChild(messageElement);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }
    
    static showLoading(element) {
        element.disabled = true;
        element.innerHTML = '<span class="spinner"></span> Loading...';
    }
    
    static hideLoading(element, originalText) {
        element.disabled = false;
        element.innerHTML = originalText;
    }
    
    static confirmAction(message) {
        return confirm(message);
    }
    
    static formatCurrency(amount) {
        return new Intl.NumberFormat('en-IN', {
            style: 'currency',
            currency: 'INR'
        }).format(amount);
    }
}

// Usage across the application
const api = new APIClient();

// In student management
async function saveStudent(studentData) {
    try {
        const result = await api.post('students/', studentData);
        UIUtils.showMessage('Student saved successfully!', 'success');
        return result;
    } catch (error) {
        UIUtils.showMessage('Failed to save student', 'error');
        throw error;
    }
}

// In fee management
async function processPayment(paymentData) {
    try {
        const result = await api.post('payments/', paymentData);
        UIUtils.showMessage(`Payment of ${UIUtils.formatCurrency(paymentData.amount)} processed!`, 'success');
        return result;
    } catch (error) {
        UIUtils.showMessage('Payment processing failed', 'error');
        throw error;
    }
}
```

## DRY Best Practices Checklist

### Code Organization
- [ ] Extract common functionality into utility classes
- [ ] Use inheritance and mixins for shared behavior
- [ ] Create base classes for common patterns
- [ ] Centralize configuration and constants
- [ ] Use dependency injection for loose coupling

### Template Management
- [ ] Create base templates for common layouts
- [ ] Use template inheritance effectively
- [ ] Build reusable template components
- [ ] Create custom template tags and filters
- [ ] Avoid duplicating template logic

### API Design
- [ ] Use base serializers for common fields
- [ ] Create generic views for standard operations
- [ ] Centralize API utilities and helpers
- [ ] Implement consistent error handling
- [ ] Use mixins for shared API behavior

### Frontend Development
- [ ] Create reusable JavaScript modules
- [ ] Use CSS custom properties for theming
- [ ] Build component libraries
- [ ] Centralize API communication logic
- [ ] Implement consistent UI patterns

### Testing
- [ ] Create base test classes
- [ ] Use factories for test data generation
- [ ] Share common test utilities
- [ ] Avoid duplicating test setup code
- [ ] Create reusable test mixins

Remember: The DRY principle is about reducing repetition of information and logic, not just code. Focus on eliminating duplication of knowledge and intent, which leads to more maintainable and reliable software.