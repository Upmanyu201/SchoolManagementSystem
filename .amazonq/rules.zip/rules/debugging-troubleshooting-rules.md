# Debugging & Troubleshooting Rules

## Core Debugging Principles

### 1. Systematic Approach
- Reproduce the issue consistently
- Isolate the problem area
- Form hypotheses and test them
- Document findings and solutions
- Verify the fix doesn't break other functionality

### 2. Evidence-Based Debugging
- Collect logs and error messages
- Use debugging tools and profilers
- Monitor system resources
- Analyze database queries
- Check network requests

### 3. Collaborative Debugging
- Share findings with team members
- Use version control to track changes
- Document known issues and solutions
- Create debugging runbooks

## Issue Identification Strategies

### 1. Error Classification
```python
# Categorize errors for faster resolution
ERROR_CATEGORIES = {
    'SYNTAX_ERROR': 'Code syntax issues',
    'LOGIC_ERROR': 'Incorrect business logic',
    'RUNTIME_ERROR': 'Errors during execution',
    'INTEGRATION_ERROR': 'Issues with external services',
    'PERFORMANCE_ERROR': 'Slow queries or operations',
    'SECURITY_ERROR': 'Authentication/authorization issues',
    'DATA_ERROR': 'Database or data integrity issues',
    'UI_ERROR': 'Frontend display or interaction issues'
}
```

### 2. Log Analysis
```python
# Good - Structured logging for debugging
import logging
import traceback

logger = logging.getLogger(__name__)

def process_student_fee(student_id, amount):
    """Process fee with comprehensive logging."""
    try:
        logger.info(f"Starting fee processing for student {student_id}, amount: {amount}")
        
        # Validate input
        if not student_id or amount <= 0:
            logger.warning(f"Invalid input: student_id={student_id}, amount={amount}")
            raise ValueError("Invalid student ID or amount")
        
        # Get student
        try:
            student = Student.objects.get(id=student_id)
            logger.debug(f"Found student: {student.admission_number}")
        except Student.DoesNotExist:
            logger.error(f"Student not found: {student_id}")
            raise
        
        # Process payment
        payment = create_payment(student, amount)
        logger.info(f"Payment created successfully: {payment.id}")
        
        return payment
        
    except Exception as e:
        logger.error(f"Error processing fee for student {student_id}: {str(e)}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        raise

# Configure logging for debugging
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'detailed': {
            'format': '{levelname} {asctime} {name} {funcName}:{lineno} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'debug_file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': 'debug.log',
            'formatter': 'detailed',
        },
    },
    'loggers': {
        'students': {
            'handlers': ['debug_file'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}
```

## Common Issue Patterns & Solutions

### 1. Database Issues

#### N+1 Query Problem
```python
# Problem - N+1 queries
def get_students_with_fees():
    students = Student.objects.all()
    for student in students:
        print(f"{student.name}: {student.fee_deposits.count()}")  # N+1 queries

# Solution - Use select_related/prefetch_related
def get_students_with_fees_optimized():
    students = Student.objects.prefetch_related('fee_deposits').all()
    for student in students:
        print(f"{student.name}: {student.fee_deposits.count()}")  # Single query

# Debug queries
from django.db import connection
from django.conf import settings

def debug_queries(func):
    """Decorator to debug database queries."""
    def wrapper(*args, **kwargs):
        if settings.DEBUG:
            initial_queries = len(connection.queries)
            result = func(*args, **kwargs)
            final_queries = len(connection.queries)
            print(f"Function {func.__name__} executed {final_queries - initial_queries} queries")
            return result
        return func(*args, **kwargs)
    return wrapper
```

#### Database Lock Issues
```python
# Problem - Database locks
def update_student_fees():
    students = Student.objects.all()
    for student in students:
        student.due_amount = calculate_due_amount(student)
        student.save()  # Potential lock issues

# Solution - Bulk operations
def update_student_fees_optimized():
    students = Student.objects.all()
    updates = []
    for student in students:
        student.due_amount = calculate_due_amount(student)
        updates.append(student)
    
    Student.objects.bulk_update(updates, ['due_amount'], batch_size=100)
```

### 2. Memory Issues

#### Memory Leaks
```python
# Problem - Loading too much data
def export_all_students():
    students = Student.objects.all()  # Loads all students into memory
    return generate_report(students)

# Solution - Use iterators
def export_all_students_optimized():
    students = Student.objects.all().iterator(chunk_size=1000)
    return generate_report_streaming(students)

# Memory monitoring
import psutil
import os

def monitor_memory_usage(func):
    """Decorator to monitor memory usage."""
    def wrapper(*args, **kwargs):
        process = psutil.Process(os.getpid())
        memory_before = process.memory_info().rss / 1024 / 1024  # MB
        
        result = func(*args, **kwargs)
        
        memory_after = process.memory_info().rss / 1024 / 1024  # MB
        print(f"Memory usage: {memory_before:.2f}MB -> {memory_after:.2f}MB "
              f"(+{memory_after - memory_before:.2f}MB)")
        
        return result
    return wrapper
```

### 3. Performance Issues

#### Slow Queries
```python
# Debug slow queries
import time
from django.db import connection

class QueryDebugMiddleware:
    """Middleware to debug slow queries."""
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        start_time = time.time()
        queries_before = len(connection.queries)
        
        response = self.get_response(request)
        
        end_time = time.time()
        queries_after = len(connection.queries)
        
        if end_time - start_time > 1:  # Slow request (>1 second)
            print(f"Slow request: {request.path}")
            print(f"Time: {end_time - start_time:.2f}s")
            print(f"Queries: {queries_after - queries_before}")
            
            # Log slow queries
            for query in connection.queries[queries_before:]:
                if float(query['time']) > 0.1:  # Slow query (>100ms)
                    print(f"Slow query ({query['time']}s): {query['sql'][:100]}...")
        
        return response
```

### 4. Frontend Issues

#### JavaScript Debugging
```javascript
// Good - Structured error handling
function processPayment(studentId, amount) {
    console.log(`Processing payment for student ${studentId}, amount: ${amount}`);
    
    try {
        // Validate input
        if (!studentId || amount <= 0) {
            throw new Error('Invalid student ID or amount');
        }
        
        // Make API call
        fetch('/api/process-payment/', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRFToken': getCsrfToken()
            },
            body: JSON.stringify({
                student_id: studentId,
                amount: amount
            })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Payment processed successfully:', data);
            showSuccessMessage('Payment processed successfully');
        })
        .catch(error => {
            console.error('Payment processing failed:', error);
            showErrorMessage('Payment processing failed: ' + error.message);
        });
        
    } catch (error) {
        console.error('Error in processPayment:', error);
        showErrorMessage('An error occurred while processing payment');
    }
}

// Debug helper functions
function debugFormData(form) {
    const formData = new FormData(form);
    console.log('Form data:');
    for (let [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
    }
}

function debugAjaxRequest(url, data) {
    console.log(`AJAX Request to ${url}:`, data);
    console.log('Request headers:', {
        'Content-Type': 'application/json',
        'X-CSRFToken': getCsrfToken()
    });
}
```

## Debugging Tools & Techniques

### 1. Django Debug Toolbar
```python
# Install and configure Django Debug Toolbar
INSTALLED_APPS = [
    # ... other apps
    'debug_toolbar',
]

MIDDLEWARE = [
    'debug_toolbar.middleware.DebugToolbarMiddleware',
    # ... other middleware
]

# Debug toolbar settings
DEBUG_TOOLBAR_CONFIG = {
    'SHOW_TOOLBAR_CALLBACK': lambda request: DEBUG,
    'SHOW_COLLAPSED': True,
}

INTERNAL_IPS = [
    '127.0.0.1',
    'localhost',
]
```

### 2. Custom Debug Views
```python
# Create debug views for troubleshooting
@staff_member_required
def debug_student_fees(request, student_id):
    """Debug view to analyze student fee calculations."""
    student = get_object_or_404(Student, id=student_id)
    
    debug_info = {
        'student': student,
        'fee_deposits': student.fee_deposits.all(),
        'applicable_fees': get_applicable_fees(student),
        'calculated_due': calculate_due_amount(student),
        'stored_due': student.due_amount,
        'discrepancy': abs(calculate_due_amount(student) - student.due_amount),
    }
    
    return render(request, 'debug/student_fees.html', debug_info)

@staff_member_required
def debug_system_health(request):
    """System health check view."""
    health_info = {
        'database_status': check_database_connection(),
        'cache_status': check_cache_connection(),
        'external_services': check_external_services(),
        'disk_space': get_disk_usage(),
        'memory_usage': get_memory_usage(),
        'recent_errors': get_recent_errors(),
    }
    
    return render(request, 'debug/system_health.html', health_info)
```

### 3. Testing for Debugging
```python
# Create specific tests to reproduce issues
class DebuggingTestCase(TestCase):
    """Test cases for debugging specific issues."""
    
    def test_fee_calculation_discrepancy(self):
        """Test to reproduce fee calculation issues."""
        student = Student.objects.create(
            first_name="Debug",
            last_name="Student",
            admission_number="DEBUG001"
        )
        
        # Create fee deposits
        FeeDeposit.objects.create(
            student=student,
            amount=1000,
            payment_date=timezone.now().date()
        )
        
        # Calculate due amount
        calculated_due = calculate_due_amount(student)
        student.update_due_amount()
        stored_due = student.due_amount
        
        # Debug output
        print(f"Calculated due: {calculated_due}")
        print(f"Stored due: {stored_due}")
        print(f"Discrepancy: {abs(calculated_due - stored_due)}")
        
        self.assertEqual(calculated_due, stored_due)
    
    def test_performance_issue(self):
        """Test to identify performance bottlenecks."""
        import time
        
        # Create test data
        students = []
        for i in range(100):
            students.append(Student(
                first_name=f"Student{i}",
                last_name="Test",
                admission_number=f"TEST{i:03d}"
            ))
        Student.objects.bulk_create(students)
        
        # Test performance
        start_time = time.time()
        result = get_students_with_fees()
        end_time = time.time()
        
        print(f"Query took {end_time - start_time:.2f} seconds")
        self.assertLess(end_time - start_time, 1.0)  # Should complete in <1 second
```

## Error Monitoring & Alerting

### 1. Error Tracking
```python
# Integrate with error tracking service (e.g., Sentry)
import sentry_sdk
from sentry_sdk.integrations.django import DjangoIntegration

sentry_sdk.init(
    dsn="your-sentry-dsn",
    integrations=[DjangoIntegration()],
    traces_sample_rate=1.0,
    send_default_pii=True
)

# Custom error handler
def handle_application_error(error, context=None):
    """Handle application errors with proper logging and alerting."""
    error_id = str(uuid.uuid4())
    
    # Log error
    logger.error(f"Application error [{error_id}]: {str(error)}", extra={
        'error_id': error_id,
        'context': context,
        'traceback': traceback.format_exc()
    })
    
    # Send to monitoring service
    sentry_sdk.capture_exception(error)
    
    # Alert if critical
    if is_critical_error(error):
        send_alert_notification(error, error_id)
    
    return error_id
```

### 2. Health Checks
```python
# Create health check endpoints
def health_check(request):
    """Basic health check endpoint."""
    checks = {
        'database': check_database(),
        'cache': check_cache(),
        'external_apis': check_external_apis(),
        'disk_space': check_disk_space(),
    }
    
    all_healthy = all(checks.values())
    status_code = 200 if all_healthy else 503
    
    return JsonResponse({
        'status': 'healthy' if all_healthy else 'unhealthy',
        'checks': checks,
        'timestamp': timezone.now().isoformat()
    }, status=status_code)

def check_database():
    """Check database connectivity."""
    try:
        from django.db import connection
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
        return True
    except Exception:
        return False
```

## Debugging Workflow

### 1. Issue Reproduction
```python
# Create reproduction script
def reproduce_issue():
    """Script to reproduce the reported issue."""
    print("Reproducing issue: Student fee calculation incorrect")
    
    # Step 1: Create test student
    student = Student.objects.create(
        first_name="Test",
        last_name="Student",
        admission_number="REPRO001"
    )
    print(f"Created student: {student}")
    
    # Step 2: Add fee deposits
    deposit = FeeDeposit.objects.create(
        student=student,
        amount=1000,
        payment_date=timezone.now().date()
    )
    print(f"Created deposit: {deposit}")
    
    # Step 3: Check calculations
    calculated = calculate_due_amount(student)
    student.update_due_amount()
    stored = student.due_amount
    
    print(f"Calculated due: {calculated}")
    print(f"Stored due: {stored}")
    print(f"Match: {calculated == stored}")
    
    return calculated == stored
```

### 2. Root Cause Analysis
```python
def analyze_fee_calculation_issue(student):
    """Analyze fee calculation discrepancies."""
    analysis = {
        'student_info': {
            'id': student.id,
            'name': student.full_name,
            'class': student.student_class.name if student.student_class else None,
        },
        'fee_structure': [],
        'deposits': [],
        'calculations': {},
        'potential_issues': []
    }
    
    # Analyze fee structure
    applicable_fees = get_applicable_fees(student)
    for fee in applicable_fees:
        analysis['fee_structure'].append({
            'type': fee.fee_type,
            'amount': fee.amount,
            'applicable': True
        })
    
    # Analyze deposits
    deposits = student.fee_deposits.all()
    for deposit in deposits:
        analysis['deposits'].append({
            'amount': deposit.amount,
            'date': deposit.payment_date,
            'type': deposit.payment_type
        })
    
    # Perform calculations
    total_fees = sum(fee.amount for fee in applicable_fees)
    total_paid = sum(deposit.amount for deposit in deposits)
    calculated_due = total_fees - total_paid
    
    analysis['calculations'] = {
        'total_fees': total_fees,
        'total_paid': total_paid,
        'calculated_due': calculated_due,
        'stored_due': student.due_amount,
        'discrepancy': abs(calculated_due - student.due_amount)
    }
    
    # Identify potential issues
    if analysis['calculations']['discrepancy'] > 0:
        analysis['potential_issues'].append("Discrepancy between calculated and stored due amount")
    
    if not applicable_fees:
        analysis['potential_issues'].append("No applicable fees found for student")
    
    return analysis
```

## Documentation & Knowledge Base

### 1. Issue Documentation
```markdown
# Issue: Student Fee Calculation Discrepancy

## Problem Description
Students showing incorrect due amounts in the system.

## Symptoms
- Calculated due amount differs from stored due amount
- Reports showing inconsistent fee data
- Parents receiving incorrect fee notifications

## Root Cause
The `update_due_amount()` method was not accounting for partial payments and discounts correctly.

## Solution
Updated the calculation logic to properly handle:
1. Partial payments
2. Discounts and scholarships
3. Carry-forward amounts

## Code Changes
- Modified `Student.update_due_amount()` method
- Added proper handling for discount calculations
- Implemented data migration to fix existing records

## Testing
- Added unit tests for fee calculations
- Verified with sample data
- Performed regression testing

## Prevention
- Added validation in fee deposit creation
- Implemented automated tests for fee calculations
- Added monitoring for calculation discrepancies
```

### 2. Debugging Checklist
```markdown
# Debugging Checklist

## Initial Assessment
- [ ] Can the issue be reproduced consistently?
- [ ] What are the exact steps to reproduce?
- [ ] What is the expected vs actual behavior?
- [ ] When did the issue first appear?
- [ ] What changed recently?

## Data Collection
- [ ] Collect relevant log files
- [ ] Gather error messages and stack traces
- [ ] Document system environment details
- [ ] Capture screenshots/videos if UI issue
- [ ] Export relevant database records

## Analysis
- [ ] Identify the affected code areas
- [ ] Check recent code changes
- [ ] Review related configuration
- [ ] Analyze database queries
- [ ] Check external service dependencies

## Testing
- [ ] Create minimal reproduction case
- [ ] Test potential fixes in isolation
- [ ] Verify fix doesn't break other functionality
- [ ] Test edge cases and error conditions
- [ ] Perform regression testing

## Documentation
- [ ] Document the issue and solution
- [ ] Update troubleshooting guides
- [ ] Share findings with team
- [ ] Update monitoring/alerting if needed
```

Remember: Effective debugging is a systematic process that combines technical skills, analytical thinking, and proper documentation to identify, resolve, and prevent issues in enterprise applications.