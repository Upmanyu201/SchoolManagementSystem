# Enterprise Code Structure Rules

## Core Principles

### 1. SOLID Principles
- **S**ingle Responsibility Principle
- **O**pen/Closed Principle  
- **L**iskov Substitution Principle
- **I**nterface Segregation Principle
- **D**ependency Inversion Principle

### 2. Clean Code Fundamentals
- Code should be readable like prose
- Functions should do one thing well
- Use meaningful names
- Keep functions and classes small
- Minimize comments by writing self-documenting code

## Function Structure

### Function Design Rules
```python
# Good - Single responsibility, clear name
def calculate_student_monthly_fee(student, month, year):
    """Calculate monthly fee for a specific student and month."""
    base_fee = get_base_fee_for_class(student.class_name)
    transport_fee = get_transport_fee(student)
    discount = calculate_discount(student, month)
    return base_fee + transport_fee - discount

# Bad - Multiple responsibilities, unclear name
def process_student(student, month, year, send_sms=False):
    # Calculates fee, sends SMS, updates database, generates report
    pass
```

### Function Size Guidelines
```python
# Good - Small, focused function
def validate_phone_number(phone):
    """Validate phone number format."""
    pattern = r'^\+?1?\d{9,15}$'
    return re.match(pattern, phone) is not None

# Good - Break down complex logic
def process_fee_payment(student, amount, payment_method):
    """Process fee payment for student."""
    validate_payment_amount(amount)
    payment = create_payment_record(student, amount, payment_method)
    update_student_balance(student, amount)
    send_payment_confirmation(student, payment)
    return payment

# Bad - Too long, multiple responsibilities
def process_everything(student, amount, method, send_sms, generate_receipt, update_records):
    # 50+ lines of mixed logic
    pass
```

## Class Structure

### Class Design Principles
```python
# Good - Single responsibility, clear interface
class FeeCalculator:
    """Handles all fee calculation logic."""
    
    def __init__(self, academic_year):
        self.academic_year = academic_year
        self.fee_structure = self._load_fee_structure()
    
    def calculate_monthly_fee(self, student):
        """Calculate monthly fee for student."""
        return self._get_base_fee(student) + self._get_additional_fees(student)
    
    def calculate_annual_fee(self, student):
        """Calculate annual fee for student."""
        return self.calculate_monthly_fee(student) * 12
    
    def _get_base_fee(self, student):
        """Private method for base fee calculation."""
        return self.fee_structure.get(student.class_name, 0)
    
    def _get_additional_fees(self, student):
        """Private method for additional fees."""
        transport_fee = self._calculate_transport_fee(student)
        activity_fee = self._calculate_activity_fee(student)
        return transport_fee + activity_fee

# Good - Composition over inheritance
class Student:
    def __init__(self, name, class_name):
        self.name = name
        self.class_name = class_name
        self.fee_calculator = FeeCalculator(academic_year=2024)
        self.payment_processor = PaymentProcessor()
    
    def get_monthly_fee(self):
        return self.fee_calculator.calculate_monthly_fee(self)
```

### Model Structure (Django)
```python
# Good - Well-structured model
class Student(BaseModel):
    """Student model with proper validation and methods."""
    
    # Fields with proper validation
    admission_number = models.CharField(
        max_length=20, 
        unique=True, 
        validators=[validate_admission_number]
    )
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField(unique=True)
    
    # Relationships
    student_class = models.ForeignKey('AcademicClass', on_delete=models.CASCADE)
    
    # Custom manager
    objects = StudentManager()
    
    class Meta:
        ordering = ['first_name', 'last_name']
        indexes = [
            models.Index(fields=['admission_number']),
            models.Index(fields=['email']),
        ]
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.admission_number})"
    
    @property
    def full_name(self):
        """Return full name of student."""
        return f"{self.first_name} {self.last_name}"
    
    def calculate_due_amount(self):
        """Calculate current due amount for student."""
        # Business logic here
        pass
    
    def send_notification(self, message):
        """Send notification to student."""
        # Notification logic here
        pass
```

## View Structure

### Function-Based Views
```python
# Good - Clean, focused view
@login_required
@require_http_methods(["GET", "POST"])
def add_student(request):
    """Add new student to the system."""
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            student = form.save()
            messages.success(request, f"Student {student.full_name} added successfully!")
            return redirect('student_list')
    else:
        form = StudentForm()
    
    context = {
        'form': form,
        'title': 'Add New Student'
    }
    return render(request, 'students/add_student.html', context)
```

### Class-Based Views
```python
# Good - Structured class-based view
class StudentListView(LoginRequiredMixin, ListView):
    """Display list of students with filtering and pagination."""
    
    model = Student
    template_name = 'students/student_list.html'
    context_object_name = 'students'
    paginate_by = 20
    
    def get_queryset(self):
        """Filter students based on user permissions and search."""
        queryset = Student.objects.select_related('student_class', 'student_section')
        
        # Apply user-based filtering
        if not self.request.user.is_superuser:
            queryset = queryset.filter(student_class__teacher=self.request.user)
        
        # Apply search filtering
        search_query = self.request.GET.get('search')
        if search_query:
            queryset = queryset.filter(
                Q(first_name__icontains=search_query) |
                Q(last_name__icontains=search_query) |
                Q(admission_number__icontains=search_query)
            )
        
        return queryset.order_by('first_name', 'last_name')
    
    def get_context_data(self, **kwargs):
        """Add additional context data."""
        context = super().get_context_data(**kwargs)
        context['title'] = 'Students List'
        context['search_query'] = self.request.GET.get('search', '')
        context['total_students'] = self.get_queryset().count()
        return context
```

## Service Layer Pattern

### Business Logic Services
```python
# Good - Separate business logic into services
class StudentService:
    """Service class for student-related business logic."""
    
    @staticmethod
    def enroll_student(student_data, user):
        """Enroll a new student with proper validation."""
        # Validate enrollment data
        StudentService._validate_enrollment_data(student_data)
        
        # Check permissions
        if not user.has_perm('students.add_student'):
            raise PermissionError("User doesn't have permission to add students")
        
        # Create student
        student = Student.objects.create(**student_data)
        
        # Initialize fee structure
        FeeService.initialize_student_fees(student)
        
        # Send welcome notification
        NotificationService.send_welcome_message(student)
        
        # Log activity
        ActivityLogger.log_student_enrollment(student, user)
        
        return student
    
    @staticmethod
    def _validate_enrollment_data(data):
        """Private method to validate enrollment data."""
        required_fields = ['first_name', 'last_name', 'admission_number']
        for field in required_fields:
            if not data.get(field):
                raise ValidationError(f"{field} is required")
        
        # Check for duplicate admission number
        if Student.objects.filter(admission_number=data['admission_number']).exists():
            raise ValidationError("Admission number already exists")

class FeeService:
    """Service class for fee-related operations."""
    
    @staticmethod
    def calculate_student_dues(student):
        """Calculate total dues for a student."""
        calculator = FeeCalculator(student.academic_year)
        return calculator.calculate_total_dues(student)
    
    @staticmethod
    def process_payment(student, amount, payment_method):
        """Process fee payment for student."""
        # Validate payment
        FeeService._validate_payment(student, amount)
        
        # Create payment record
        payment = FeePayment.objects.create(
            student=student,
            amount=amount,
            payment_method=payment_method,
            processed_by=get_current_user()
        )
        
        # Update student balance
        student.update_due_amount()
        
        # Send confirmation
        NotificationService.send_payment_confirmation(student, payment)
        
        return payment
```

## Error Handling Structure

### Structured Exception Handling
```python
# Good - Custom exceptions
class StudentManagementError(Exception):
    """Base exception for student management operations."""
    pass

class StudentNotFoundError(StudentManagementError):
    """Raised when student is not found."""
    pass

class InsufficientPermissionError(StudentManagementError):
    """Raised when user lacks required permissions."""
    pass

class InvalidPaymentError(StudentManagementError):
    """Raised when payment validation fails."""
    pass

# Good - Structured error handling
def process_student_payment(student_id, amount):
    """Process payment with proper error handling."""
    try:
        student = Student.objects.get(id=student_id)
    except Student.DoesNotExist:
        raise StudentNotFoundError(f"Student with ID {student_id} not found")
    
    try:
        payment = FeeService.process_payment(student, amount, 'cash')
        logger.info(f"Payment processed successfully for student {student.admission_number}")
        return payment
    except ValidationError as e:
        logger.warning(f"Payment validation failed: {e}")
        raise InvalidPaymentError(f"Payment validation failed: {e}")
    except Exception as e:
        logger.error(f"Unexpected error processing payment: {e}")
        raise StudentManagementError(f"Failed to process payment: {e}")
```

## Configuration Structure

### Settings Organization
```python
# Good - Organized settings structure
class BaseSettings:
    """Base settings for all environments."""
    
    # Core Django settings
    SECRET_KEY = os.environ.get('SECRET_KEY')
    DEBUG = False
    ALLOWED_HOSTS = []
    
    # Application definition
    DJANGO_APPS = [
        'django.contrib.admin',
        'django.contrib.auth',
        # ... other Django apps
    ]
    
    THIRD_PARTY_APPS = [
        'rest_framework',
        'corsheaders',
        # ... other third-party apps
    ]
    
    LOCAL_APPS = [
        'core',
        'students',
        'fees',
        # ... local apps
    ]
    
    INSTALLED_APPS = DJANGO_APPS + THIRD_PARTY_APPS + LOCAL_APPS

class DevelopmentSettings(BaseSettings):
    """Development environment settings."""
    DEBUG = True
    ALLOWED_HOSTS = ['localhost', '127.0.0.1']

class ProductionSettings(BaseSettings):
    """Production environment settings."""
    DEBUG = False
    ALLOWED_HOSTS = ['yourdomain.com']
```

## Testing Structure

### Test Organization
```python
# Good - Well-structured tests
class StudentModelTest(TestCase):
    """Test cases for Student model."""
    
    def setUp(self):
        """Set up test data."""
        self.student_data = {
            'first_name': 'John',
            'last_name': 'Doe',
            'admission_number': 'STU001',
            'email': 'john.doe@example.com'
        }
    
    def test_student_creation(self):
        """Test student creation with valid data."""
        student = Student.objects.create(**self.student_data)
        self.assertEqual(student.full_name, 'John Doe')
        self.assertEqual(str(student), 'John Doe (STU001)')
    
    def test_student_validation(self):
        """Test student validation rules."""
        # Test duplicate admission number
        Student.objects.create(**self.student_data)
        with self.assertRaises(IntegrityError):
            Student.objects.create(**self.student_data)
    
    def test_due_amount_calculation(self):
        """Test due amount calculation."""
        student = Student.objects.create(**self.student_data)
        due_amount = student.calculate_due_amount()
        self.assertIsInstance(due_amount, Decimal)
        self.assertGreaterEqual(due_amount, 0)

class StudentServiceTest(TestCase):
    """Test cases for StudentService."""
    
    def test_enroll_student_success(self):
        """Test successful student enrollment."""
        user = User.objects.create_user('admin', 'admin@test.com', 'password')
        student_data = {
            'first_name': 'Jane',
            'last_name': 'Smith',
            'admission_number': 'STU002'
        }
        
        student = StudentService.enroll_student(student_data, user)
        self.assertIsInstance(student, Student)
        self.assertEqual(student.first_name, 'Jane')
```

## Code Quality Guidelines

### Naming Conventions
```python
# Good - Descriptive names
def calculate_monthly_fee_for_student(student, month):
    pass

class StudentFeeCalculator:
    pass

MAXIMUM_FILE_SIZE = 5 * 1024 * 1024  # 5MB

# Bad - Unclear names
def calc(s, m):
    pass

class SFC:
    pass

MAX_SIZE = 5242880
```

### Documentation Standards
```python
# Good - Comprehensive docstrings
def process_fee_payment(student, amount, payment_method='cash'):
    """
    Process fee payment for a student.
    
    Args:
        student (Student): The student making the payment
        amount (Decimal): Payment amount
        payment_method (str): Payment method ('cash', 'card', 'online')
    
    Returns:
        FeePayment: Created payment record
    
    Raises:
        ValidationError: If payment amount is invalid
        InsufficientFundsError: If payment exceeds due amount
    
    Example:
        >>> student = Student.objects.get(admission_number='STU001')
        >>> payment = process_fee_payment(student, Decimal('1000.00'), 'cash')
        >>> print(payment.amount)
        1000.00
    """
    pass
```

### Code Review Checklist
- [ ] Functions have single responsibility
- [ ] Classes follow SOLID principles
- [ ] Proper error handling implemented
- [ ] Code is well-documented
- [ ] Tests cover main functionality
- [ ] No code duplication
- [ ] Consistent naming conventions
- [ ] Security considerations addressed
- [ ] Performance implications considered
- [ ] Dependencies properly managed

Remember: Good code structure is the foundation of maintainable, scalable, and reliable enterprise applications.